import axios from 'axios';
import * as schema from '@shared/schema';
import { db } from '@db';
import { eq } from 'drizzle-orm';

// YouTube API base URL
const YOUTUBE_API_BASE_URL = 'https://www.googleapis.com/youtube/v3';
const YOUTUBE_API_KEY = process.env.YOUTUBE_API_KEY;

// Define interfaces for YouTube API responses
interface YouTubeChannelListResponse {
  items: YouTubeChannel[];
  nextPageToken?: string;
  pageInfo: {
    totalResults: number;
    resultsPerPage: number;
  };
}

interface YouTubeSearchListResponse {
  items: YouTubeSearchItem[];
  nextPageToken?: string;
  pageInfo: {
    totalResults: number;
    resultsPerPage: number;
  };
}

interface YouTubeStatisticsResponse {
  items: YouTubeChannelStatistics[];
}

interface YouTubeChannel {
  id: string;
  snippet: {
    title: string;
    description: string;
    customUrl?: string;
    publishedAt: string;
    thumbnails: {
      default: { url: string };
      medium: { url: string };
      high: { url: string };
    };
    localized: {
      title: string;
      description: string;
    };
    country?: string;
  };
  brandingSettings?: {
    image?: {
      bannerExternalUrl?: string;
    };
  };
  statistics: {
    viewCount: string;
    subscriberCount: string;
    videoCount: string;
  };
  contentDetails?: {
    relatedPlaylists: {
      uploads: string;
    };
  };
}

interface YouTubeSearchItem {
  id: {
    kind: string;
    channelId?: string;
    videoId?: string;
  };
  snippet: {
    channelId: string;
    channelTitle: string;
    title: string;
    description: string;
    thumbnails: {
      default: { url: string };
      medium: { url: string };
      high: { url: string };
    };
    publishedAt: string;
  };
}

interface YouTubeChannelStatistics {
  id: string;
  statistics: {
    viewCount: string;
    subscriberCount: string;
    videoCount: string;
  };
}

interface VideoStatistics {
  viewCount: number;
  likeCount: number;
  commentCount: number;
}

// Calculate engagement rate based on video statistics
const calculateEngagementRate = (stats: VideoStatistics, subscriberCount: number): number => {
  if (!subscriberCount) return 0;
  
  // Engagement is (likes + comments) / views * 100
  const engagement = (stats.likeCount + stats.commentCount) / stats.viewCount;
  
  // Normalize based on subscriber count (larger channels tend to have lower engagement)
  return +(engagement * 100).toFixed(2);
};

// Get estimated cost based on subscriber count and engagement
const estimateInfluencerCost = (subscribers: number, engagementRate: number): number => {
  // Base rate
  let baseCost = 0;
  
  // Subscriber-based tiers
  if (subscribers < 10000) baseCost = 100;
  else if (subscribers < 50000) baseCost = 350;
  else if (subscribers < 100000) baseCost = 500;
  else if (subscribers < 500000) baseCost = 1000;
  else if (subscribers < 1000000) baseCost = 2000;
  else baseCost = 5000;
  
  // Apply engagement multiplier (higher engagement = higher cost)
  const engagementMultiplier = 1 + (engagementRate / 100);
  
  return Math.round(baseCost * engagementMultiplier);
};

// Convert YouTube channel to our Influencer schema
const convertToInfluencer = async (
  channel: YouTubeChannel, 
  categoryIds: number[] = []
): Promise<schema.InsertInfluencer> => {
  const subscribers = parseInt(channel.statistics.subscriberCount) || 0;
  const totalViews = parseInt(channel.statistics.viewCount) || 0;
  const videoCount = parseInt(channel.statistics.videoCount) || 0;
  
  // Calculate average views per video
  const avgViews = videoCount ? Math.round(totalViews / videoCount) : 0;
  
  // Calculate approximate engagement rate (would be more accurate with actual video data)
  // For demo purposes, we'll estimate using a simple formula
  const approxEngagementRate = (subscribers > 0) 
    ? +(4 + (Math.random() * 2)).toFixed(2) // Random between 4-6% as a placeholder
    : 0;
  
  // Extract displayName from the channel title
  const displayName = channel.snippet.title;
  
  return {
    channelId: channel.id,
    channelTitle: channel.snippet.title,
    displayName,
    profileImageUrl: channel.snippet.thumbnails.high.url,
    bannerImageUrl: channel.brandingSettings?.image?.bannerExternalUrl || 
                    'https://images.unsplash.com/photo-1607979036233-ec96750c9e80',  // Default banner
    description: channel.snippet.description,
    subscribers,
    totalViews,
    avgViews,
    engagementRate: approxEngagementRate.toString(),
    estimatedCost: estimateInfluencerCost(subscribers, approxEngagementRate).toString(),
    location: channel.snippet.country || 'Unknown',
    categories: categoryIds,
    tags: [], // Would need additional API calls to determine tags accurately
    lastUpdated: new Date(),
  };
};

export const youtubeService = {
  // Search for YouTube channels based on query
  async searchChannels(query: string, maxResults: number = 10): Promise<YouTubeSearchItem[]> {
    try {
      const response = await axios.get<YouTubeSearchListResponse>(`${YOUTUBE_API_BASE_URL}/search`, {
        params: {
          part: 'snippet',
          q: query,
          type: 'channel',
          maxResults,
          key: YOUTUBE_API_KEY
        }
      });
      
      return response.data.items;
    } catch (error) {
      console.error('Error searching YouTube channels:', error);
      throw new Error('Failed to search YouTube channels');
    }
  },
  
  // Get detailed channel information
  async getChannelDetails(channelId: string): Promise<YouTubeChannel | null> {
    try {
      const response = await axios.get<YouTubeChannelListResponse>(`${YOUTUBE_API_BASE_URL}/channels`, {
        params: {
          part: 'snippet,statistics,brandingSettings',
          id: channelId,
          key: YOUTUBE_API_KEY
        }
      });
      
      if (response.data.items.length === 0) {
        return null;
      }
      
      return response.data.items[0];
    } catch (error) {
      console.error('Error getting YouTube channel details:', error);
      throw new Error('Failed to get YouTube channel details');
    }
  },
  
  // Get multiple channels by ID
  async getChannelsByIds(channelIds: string[]): Promise<YouTubeChannel[]> {
    try {
      const response = await axios.get<YouTubeChannelListResponse>(`${YOUTUBE_API_BASE_URL}/channels`, {
        params: {
          part: 'snippet,statistics,brandingSettings',
          id: channelIds.join(','),
          maxResults: channelIds.length,
          key: YOUTUBE_API_KEY
        }
      });
      
      return response.data.items || [];
    } catch (error) {
      console.error('Error getting multiple YouTube channels:', error);
      throw new Error('Failed to get YouTube channels');
    }
  },
  
  // Fetch and store influencer from YouTube
  async fetchAndStoreInfluencer(channelId: string, categoryIds: number[] = []): Promise<schema.Influencer | null> {
    try {
      // Check if influencer already exists in our database
      const existingInfluencer = await db.query.influencers.findFirst({
        where: (influencers, { eq }) => eq(influencers.channelId, channelId)
      });
      
      if (existingInfluencer) {
        return existingInfluencer;
      }
      
      // Fetch channel details from YouTube
      const channelDetails = await this.getChannelDetails(channelId);
      if (!channelDetails) {
        return null;
      }
      
      // Convert to our schema
      const influencerData = await convertToInfluencer(channelDetails, categoryIds);
      
      // Store in database
      const [newInfluencer] = await db.insert(schema.influencers)
        .values(influencerData)
        .returning();
      
      return newInfluencer;
    } catch (error) {
      console.error('Error fetching and storing influencer:', error);
      throw new Error('Failed to fetch and store influencer');
    }
  },
  
  // Search and store multiple channels with subscriber filtering
  async searchAndStoreChannels(
    query: string, 
    categoryIds: number[] = [], 
    maxResults: number = 5,
    minSubscribers: number = 0
  ): Promise<schema.Influencer[]> {
    try {
      // Enhanced logic for beauty/fashion campaigns
      let isBeautyOrFashion = false;
      if (categoryIds.includes(7) || categoryIds.includes(10)) { // Beauty or Fashion categories
        isBeautyOrFashion = true;
        
        // Always add beauty terms to query for these categories
        if (!query.toLowerCase().includes('beauty') && 
            !query.toLowerCase().includes('makeup') && 
            !query.toLowerCase().includes('cosmetic')) {
          query = `${query} beauty makeup tutorial`;
        }
        console.log(`Enhanced beauty search query: "${query}"`);
      }
      
      // For high-subscriber searches we'll use a more aggressive approach
      const isHighSubscriber = minSubscribers >= 500000;
      
      // If we're looking for high-subscriber accounts, search more channels
      // Especially for beauty/fashion which often needs more results to find matches
      const searchMultiplier = (isHighSubscriber && isBeautyOrFashion) ? 6 : 
                             (isHighSubscriber) ? 4 : 
                             (isBeautyOrFashion) ? 3 : 2;
      
      // Search for channels on YouTube - get more results to filter after
      console.log(`Searching YouTube for channels with query: "${query}" (multiplier: ${searchMultiplier})`);
      const searchResults = await this.searchChannels(query, maxResults * searchMultiplier);
      
      // Extract channel IDs
      const channelIds = searchResults.map(item => item.id.channelId).filter(Boolean) as string[];
      
      if (channelIds.length === 0) {
        console.log("No YouTube channel IDs found in search results");
        return [];
      }
      
      console.log(`Found ${channelIds.length} channels from search, fetching details...`);
      
      // Get detailed information for each channel
      const channelDetails = await this.getChannelsByIds(channelIds);
      
      // Pre-filter channels by subscriber count if needed
      let filteredChannels = channelDetails;
      if (minSubscribers > 0) {
        console.log(`Filtering channels with at least ${minSubscribers.toLocaleString()} subscribers`);
        filteredChannels = channelDetails.filter(channel => {
          const subscriberCount = parseInt(channel.statistics.subscriberCount || '0');
          const meetsRequirement = subscriberCount >= minSubscribers;
          console.log(`Channel ${channel.snippet.title}: ${subscriberCount.toLocaleString()} subscribers - ${meetsRequirement ? 'KEEP' : 'FILTER OUT'}`);
          return meetsRequirement;
        });
        
        console.log(`After filtering: ${filteredChannels.length} channels meet the ${minSubscribers.toLocaleString()} subscriber requirement`);
        
        // For beauty campaigns with high subscriber requirements, we need special handling
        if (filteredChannels.length < 3 && isHighSubscriber && isBeautyOrFashion) {
          // Use a more aggressive strategy with specific beauty influencer searches
          console.log("Not enough high-subscriber beauty channels found, running specialized searches...");
          
          // These are targeted searches specifically for high-subscriber beauty channels
          const beautySearches = [
            "famous beauty influencer", 
            "top makeup youtuber millions",
            "beauty guru million subscribers",
            "makeup artist famous youtuber",
            "cosmetics influencer popular",
            "skincare influencer trending",
            "high end makeup tutorial",
            "beauty product review million views"
          ];
          
          // Try each query until we have enough channels
          for (const beautyQuery of beautySearches) {
            if (filteredChannels.length >= 5) break; // Stop if we have enough
            
            console.log(`Running targeted beauty search: "${beautyQuery}"`);
            const additionalResults = await this.searchChannels(beautyQuery, 15);
            const additionalIds = additionalResults.map(item => item.id.channelId).filter(Boolean) as string[];
            
            // Skip IDs we already processed
            const newIds = additionalIds.filter(id => !channelIds.includes(id));
            if (newIds.length === 0) continue;
            
            // Add to our tracking array
            channelIds.push(...newIds);
            
            // Get details for new IDs
            const additionalDetails = await this.getChannelsByIds(newIds);
            
            // Filter for high subscribers
            const highSubAdditional = additionalDetails.filter(channel => {
              const subCount = parseInt(channel.statistics.subscriberCount || '0');
              const meetsRequirement = subCount >= minSubscribers;
              
              // Check if we already have this channel
              const isDuplicate = filteredChannels.some(existing => existing.id === channel.id);
              
              if (meetsRequirement && !isDuplicate) {
                console.log(`Found high-subscriber beauty channel: ${channel.snippet.title} (${subCount.toLocaleString()})`);
                return true;
              }
              return false;
            });
            
            console.log(`Found ${highSubAdditional.length} additional high-subscriber beauty channels`);
            
            // Add to our filtered results
            filteredChannels = [...filteredChannels, ...highSubAdditional];
          }
          
          // If we still don't have enough, try a last-resort approach by slightly lowering the subscriber threshold
          if (filteredChannels.length < 3 && minSubscribers > 300000) {
            console.log("Still insufficient results, checking for channels with slightly lower subscriber counts...");
            const lowerThreshold = minSubscribers * 0.7; // 70% of the original threshold
            
            const almostHighEnough = channelDetails.filter(channel => {
              const subCount = parseInt(channel.statistics.subscriberCount || '0');
              return subCount >= lowerThreshold && subCount < minSubscribers;
            });
            
            console.log(`Found ${almostHighEnough.length} channels with ${lowerThreshold.toLocaleString()}-${minSubscribers.toLocaleString()} subscribers`);
            
            // Add these to our filtered results
            filteredChannels = [...filteredChannels, ...almostHighEnough];
          }
        }
      }
      
      // Limit results after filtering to avoid adding too many at once
      filteredChannels = filteredChannels.slice(0, maxResults);
      
      // Set default tags for beauty channels
      const beautyTags = ['beauty', 'makeup', 'skincare'];
      const fashionTags = ['fashion', 'style', 'clothing'];
      
      // Convert and store each channel
      const storedInfluencers = await Promise.all(
        filteredChannels.map(async (channel) => {
          try {
            // Check if influencer already exists
            const existing = await db.query.influencers.findFirst({
              where: (influencers, { eq }) => eq(influencers.channelId, channel.id)
            });
            
            // Convert to our schema
            const influencerData = await convertToInfluencer(channel, categoryIds);
            
            // Make sure tags is a proper array
            let currentTags: string[] = Array.isArray(influencerData.tags) 
              ? influencerData.tags as string[] 
              : [];
              
            // Add appropriate tags based on categories
            if (categoryIds.includes(7)) { // Beauty category
              // Add beauty tags
              beautyTags.forEach(tag => {
                if (!currentTags.includes(tag)) {
                  currentTags.push(tag);
                }
              });
            }
            
            if (categoryIds.includes(10)) { // Fashion category
              // Add fashion tags
              fashionTags.forEach(tag => {
                if (!currentTags.includes(tag)) {
                  currentTags.push(tag);
                }
              });
            }
            
            // Update the influencer data with the new tags
            influencerData.tags = currentTags;
            
            if (existing) {
              // Update existing influencer with fresh data from YouTube
              console.log(`Updating existing influencer: ${channel.snippet.title}`);
              const [updatedInfluencer] = await db.update(schema.influencers)
                .set({
                  // Update statistics data which changes frequently
                  subscribers: influencerData.subscribers,
                  totalViews: influencerData.totalViews,
                  avgViews: influencerData.avgViews,
                  engagementRate: influencerData.engagementRate,
                  // Update category mapping and tags
                  categories: categoryIds,
                  tags: influencerData.tags,
                  lastUpdated: new Date()
                })
                .where(eq(schema.influencers.id, existing.id))
                .returning();
              
              return updatedInfluencer;
            } else {
              // Store new influencer in database
              console.log(`Adding new influencer: ${channel.snippet.title} with ${influencerData.subscribers.toLocaleString()} subscribers`);
              const [newInfluencer] = await db.insert(schema.influencers)
                .values(influencerData)
                .returning();
                
              return newInfluencer;
            }
          } catch (error) {
            console.error(`Error storing channel ${channel.id}:`, error);
            return null;
          }
        })
      );
      
      // Filter out any nulls
      return storedInfluencers.filter(Boolean) as schema.Influencer[];
    } catch (error) {
      console.error('Error searching and storing channels:', error);
      throw new Error('Failed to search and store channels');
    }
  }
};