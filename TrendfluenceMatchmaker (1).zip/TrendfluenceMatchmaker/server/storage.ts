import { db } from "@db";
import * as schema from "@shared/schema";
import { eq, and, desc, inArray, like, gte, lte, or, sql } from "drizzle-orm";
import { PostgresJsDatabase } from "drizzle-orm/postgres-js";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

// Password hashing function
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// Password comparison function
export async function comparePasswords(supplied: string, stored: string): Promise<boolean> {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export type ScoreWeights = {
  performanceWeight: number;
  audienceWeight: number;
  contentWeight: number;
  budgetWeight: number;
};

export const DEFAULT_SCORE_WEIGHTS: ScoreWeights = {
  performanceWeight: 0.2,  // Reduced from 0.3
  audienceWeight: 0.4,     // Increased from 0.3
  contentWeight: 0.3,      // Kept the same
  budgetWeight: 0.1,       // Kept the same
};

// In-memory user storage for development
const users = [
  {
    id: 1,
    username: "testuser",
    password: "will-be-replaced-with-hash",
    email: "test@example.com",
    companyName: "Test Company",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

// Hash the test user's password on initialization
(async () => {
  users[0].password = await hashPassword("password123");
})();

let nextId = 2; // For new users

export const storage = {
  // User operations with in-memory storage
  async getUserById(id: number) {
    return users.find(user => user.id === id);
  },

  async getUserByUsername(username: string) {
    return users.find(user => user.username === username);
  },

  async getUserByEmail(email: string) {
    return users.find(user => user.email === email);
  },

  async createUser(userData: schema.InsertUser) {
    // Check if username already exists
    if (users.some(user => user.username === userData.username)) {
      throw new Error("Username already exists");
    }

    // Check if email already exists
    if (users.some(user => user.email === userData.email)) {
      throw new Error("Email already exists");
    }
    
    // Hash the password before storing it
    const hashedPassword = await hashPassword(userData.password);
    
    const newUser = {
      id: nextId++,
      ...userData,
      password: hashedPassword,
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    users.push(newUser);
    
    // Return copy without password
    const { password, ...userWithoutPassword } = newUser;
    return userWithoutPassword;
  },

  async authenticateUser(username: string, password: string) {
    const user = await this.getUserByUsername(username);
    if (!user) return null;
    
    const passwordMatch = await comparePasswords(password, user.password);
    if (!passwordMatch) return null;
    
    // Remove the password from the returned user
    const { password: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
  },
  
  // Category operations
  async getAllCategories() {
    return db.select().from(schema.categories).orderBy(schema.categories.name);
  },

  async getCategoryById(id: number) {
    return db.query.categories.findFirst({
      where: eq(schema.categories.id, id),
    });
  },

  // Campaign operations
  async createCampaign(campaignData: schema.InsertCampaign) {
    const [campaign] = await db.insert(schema.campaigns)
      .values(campaignData)
      .returning();
    return campaign;
  },

  async getCampaignById(id: number) {
    return db.query.campaigns.findFirst({
      where: eq(schema.campaigns.id, id),
      with: {
        targetAudience: true,
        influencerCriteria: true,
      },
    });
  },

  async getAllCampaigns() {
    return db.query.campaigns.findMany({
      orderBy: desc(schema.campaigns.createdAt),
    });
  },

  async updateCampaign(id: number, campaignData: Partial<schema.InsertCampaign>) {
    const [updatedCampaign] = await db.update(schema.campaigns)
      .set({ ...campaignData, updatedAt: new Date() })
      .where(eq(schema.campaigns.id, id))
      .returning();
    return updatedCampaign;
  },

  async deleteCampaign(id: number) {
    // First delete all related data (target audience, influencer criteria, influencer matches)
    // Delete target audience
    await db.delete(schema.campaignTargetAudience)
      .where(eq(schema.campaignTargetAudience.campaignId, id));
    
    // Delete influencer criteria
    await db.delete(schema.campaignInfluencerCriteria)
      .where(eq(schema.campaignInfluencerCriteria.campaignId, id));
    
    // Delete influencer matches
    await db.delete(schema.influencerMatches)
      .where(eq(schema.influencerMatches.campaignId, id));
    
    // Finally delete the campaign
    const [deletedCampaign] = await db.delete(schema.campaigns)
      .where(eq(schema.campaigns.id, id))
      .returning();
    
    return deletedCampaign;
  },

  // Target audience operations
  async createTargetAudience(audienceData: schema.InsertTargetAudience) {
    const [audience] = await db.insert(schema.campaignTargetAudience)
      .values(audienceData)
      .returning();
    return audience;
  },

  async getTargetAudienceByCampaignId(campaignId: number) {
    return db.query.campaignTargetAudience.findFirst({
      where: eq(schema.campaignTargetAudience.campaignId, campaignId),
    });
  },

  async updateTargetAudience(id: number, audienceData: Partial<schema.InsertTargetAudience>) {
    const [updatedAudience] = await db.update(schema.campaignTargetAudience)
      .set(audienceData)
      .where(eq(schema.campaignTargetAudience.id, id))
      .returning();
    return updatedAudience;
  },

  // Influencer criteria operations
  async createInfluencerCriteria(criteriaData: schema.InsertInfluencerCriteria) {
    const [criteria] = await db.insert(schema.campaignInfluencerCriteria)
      .values(criteriaData)
      .returning();
    return criteria;
  },

  async getInfluencerCriteriaByCampaignId(campaignId: number) {
    return db.query.campaignInfluencerCriteria.findFirst({
      where: eq(schema.campaignInfluencerCriteria.campaignId, campaignId),
    });
  },

  async updateInfluencerCriteria(id: number, criteriaData: Partial<schema.InsertInfluencerCriteria>) {
    const [updatedCriteria] = await db.update(schema.campaignInfluencerCriteria)
      .set(criteriaData)
      .where(eq(schema.campaignInfluencerCriteria.id, id))
      .returning();
    return updatedCriteria;
  },

  // Influencer operations
  async getAllInfluencers() {
    return db.select().from(schema.influencers);
  },

  async getInfluencerById(id: number) {
    return db.query.influencers.findFirst({
      where: eq(schema.influencers.id, id),
    });
  },

  async searchInfluencers(query: string) {
    return db.select().from(schema.influencers)
      .where(
        or(
          like(schema.influencers.channelTitle, `%${query}%`),
          like(schema.influencers.displayName, `%${query}%`),
          like(schema.influencers.description, `%${query}%`)
        )
      );
  },

  async filterInfluencers(options: {
    categories?: number[];
    minSubscribers?: number;
    minEngagementRate?: number;
    locations?: string[];
    tags?: string[];
  }) {
    // Debug the options being passed
    console.log("Filtering influencers with criteria:", JSON.stringify(options, null, 2));
    
    // Ensure minSubscribers is a number
    const minSubs = typeof options.minSubscribers === 'string' 
      ? parseInt(options.minSubscribers) 
      : (options.minSubscribers || 0);
    
    // Critical logging to verify the actual value
    console.log(`Minimum subscribers value (parsed): ${minSubs}`);
    
    let query = db.select().from(schema.influencers);

    // Build conditions array instead of chaining where clauses
    let conditions = [];
    
    // We need to handle categories as a top priority for filtering
    if (options.categories && options.categories.length > 0) {
      console.log(`Filtering by categories: ${options.categories.join(', ')}`);
      
      // Use direct string comparison for simplicity instead of json array operations
      // Convert categories array to jsonb string representation for comparison
      const categoryStr = JSON.stringify(options.categories);
      conditions.push(sql`${schema.influencers.categories}::text LIKE ${'%' + categoryStr.substring(1, categoryStr.length - 1) + '%'}`);
      
      // Log for debugging
      console.log(`Using category filter: ${categoryStr}`);
    }
    
    // CRITICAL: Filter by minimum subscribers
    if (minSubs > 0) {
      console.log(`Applying minimum subscribers filter: ${minSubs}`);
      // Force strict numeric comparison for subscribers with double type checking
      conditions.push(
        sql`cast(${schema.influencers.subscribers} as integer) >= ${minSubs}`
      );
    }

    if (options.minEngagementRate && options.minEngagementRate > 0) {
      console.log(`Applying minimum engagement rate filter: ${options.minEngagementRate}`);
      // Force strict numeric comparison for engagement rate
      conditions.push(
        sql`cast(${schema.influencers.engagementRate} as float) >= ${options.minEngagementRate}`
      );
    }
    
    // Apply all conditions to a fresh query
    let finalQuery;
    if (conditions.length > 0) {
      // Combine all conditions with AND
      const whereClause = conditions.reduce((combined, condition, index) => {
        if (index === 0) return condition;
        return sql`${combined} AND ${condition}`;
      }, sql`1=1`);
      
      // Create a new query with the combined condition
      finalQuery = db.select().from(schema.influencers).where(whereClause);
    } else {
      finalQuery = db.select().from(schema.influencers);
    }
    
    // Log debug info
    console.log("Final SQL info:", finalQuery.toSQL());
    
    // Execute query immediately to log results for debugging
    console.log(`Searching for influencers with min ${options.minSubscribers} subscribers...`);
    
    // Return a promise that will execute the query
    return finalQuery.execute();
  },

  // Matching operations
  async createInfluencerMatch(matchData: schema.InsertInfluencerMatch) {
    const [match] = await db.insert(schema.influencerMatches)
      .values(matchData)
      .returning();
    return match;
  },

  async getInfluencerMatchesByCampaignId(campaignId: number) {
    return db.query.influencerMatches.findMany({
      where: eq(schema.influencerMatches.campaignId, campaignId),
      with: {
        influencer: true,
      },
      orderBy: desc(schema.influencerMatches.overallScore),
    });
  },

  async getTopInfluencerMatches(campaignId: number, limit: number = 10) {
    return db.query.influencerMatches.findMany({
      where: eq(schema.influencerMatches.campaignId, campaignId),
      with: {
        influencer: true,
      },
      orderBy: desc(schema.influencerMatches.overallScore),
      limit,
    });
  },

  // Matching algorithm
  async findMatchingInfluencers(campaignId: number, weights: ScoreWeights = DEFAULT_SCORE_WEIGHTS) {
    // Get campaign details
    const campaign = await this.getCampaignById(campaignId);
    if (!campaign) {
      throw new Error("Campaign not found");
    }

    // Get campaign audience and criteria
    const targetAudience = await this.getTargetAudienceByCampaignId(campaignId);
    const influencerCriteria = await this.getInfluencerCriteriaByCampaignId(campaignId);

    if (!targetAudience || !influencerCriteria) {
      throw new Error("Campaign audience or criteria not found");
    }

    // Get all potential influencers based on basic criteria
    console.log("Finding influencers for campaign with criteria:", {
      minSubscribers: influencerCriteria.minSubscribers,
      minEngagementRate: influencerCriteria.minEngagementRate,
      categories: influencerCriteria.categories
    });
    
    // Check if this is a beauty or fashion campaign which needs special handling
    const campaignCategories = influencerCriteria.categories as number[] || [];
    const isBeautyOrFashion = campaignCategories.includes(7) || campaignCategories.includes(10);
    
    // Build filtering options - we'll be more lenient with beauty/fashion campaigns 
    // since they're harder to match with high subscriber counts
    const filterOptions = {
      categories: campaignCategories,
      minSubscribers: Number(influencerCriteria.minSubscribers),
      minEngagementRate: Number(influencerCriteria.minEngagementRate),
    };
    
    // For beauty campaigns with high subscriber requirements, be slightly more flexible
    if (isBeautyOrFashion && Number(influencerCriteria.minSubscribers) > 500000) {
      console.log("This is a high-subscriber beauty campaign - using more flexible matching");
      
      // First try with exact requirements
      const strictInfluencers = await this.filterInfluencers(filterOptions);
      
      if (strictInfluencers.length >= 3) {
        // We have enough matches with strict criteria
        console.log(`Found ${strictInfluencers.length} influencers with exact criteria match`);
        return this.processMatches(strictInfluencers, campaign, targetAudience, influencerCriteria, weights);
      }
      
      // Not enough matches, try with slightly relaxed subscriber requirement
      console.log("Not enough matches with strict criteria, trying with relaxed subscriber count");
      const relaxedOptions = {
        ...filterOptions,
        minSubscribers: Math.floor(Number(influencerCriteria.minSubscribers) * 0.8) // 80% of original
      };
      
      const relaxedInfluencers = await this.filterInfluencers(relaxedOptions);
      console.log(`Found ${relaxedInfluencers.length} influencers with relaxed criteria`);
      
      if (relaxedInfluencers.length > 0) {
        return this.processMatches(relaxedInfluencers, campaign, targetAudience, influencerCriteria, weights);
      }
      
      // Still no matches, fall back to any beauty/fashion influencers regardless of subscriber count
      console.log("Still no matches, falling back to any beauty/fashion influencers");
      const lastResortOptions = {
        categories: campaignCategories,
        minSubscribers: 10000, // Much lower minimum
        minEngagementRate: 1.0, // Lower engagement threshold
      };
      
      const lastResortInfluencers = await this.filterInfluencers(lastResortOptions);
      console.log(`Found ${lastResortInfluencers.length} influencers with minimal criteria`);
      
      if (lastResortInfluencers.length > 0) {
        return this.processMatches(lastResortInfluencers, campaign, targetAudience, influencerCriteria, weights);
      }
      
      console.warn("No influencers found despite all fallback options!");
      return [];
    }
    
    // Standard matching for non-beauty or lower subscriber campaigns
    const influencers = await this.filterInfluencers(filterOptions);
    
    console.log(`Found ${influencers.length} influencers that match the minimum criteria`);
    if (influencers.length === 0) {
      console.warn("No influencers found that match the criteria! Check if criteria are too restrictive.");
      return [];
    }
    
    return this.processMatches(influencers, campaign, targetAudience, influencerCriteria, weights);
  },
  
  // Helper method to calculate and store matches
  async processMatches(
    influencers: schema.Influencer[], 
    campaign: schema.Campaign,
    targetAudience: schema.TargetAudience,
    influencerCriteria: schema.InfluencerCriteria, 
    weights: ScoreWeights
  ) {

    // Calculate scores for each influencer
    const matches = await Promise.all(
      influencers.map(async (influencer) => {
        // Calculate performance score (based on subscribers, views, engagement)
        const performanceScore = this.calculatePerformanceScore(influencer, influencerCriteria);
        
        // Calculate audience score (match with target demographics)
        const audienceScore = this.calculateAudienceScore(influencer, targetAudience);
        
        // Calculate content score (relevance to campaign)
        const contentScore = this.calculateContentScore(influencer, influencerCriteria);
        
        // Calculate budget score (cost effectiveness relative to campaign budget)
        const budgetScore = this.calculateBudgetScore(influencer, campaign);
        
        // Calculate weighted overall score
        const overallScore = (
          performanceScore * weights.performanceWeight +
          audienceScore * weights.audienceWeight +
          contentScore * weights.contentWeight +
          budgetScore * weights.budgetWeight
        );

        // Create and store the match - convert scores to strings for database compatibility
        const matchData: schema.InsertInfluencerMatch = {
          campaignId,
          influencerId: influencer.id,
          performanceScore: performanceScore.toString(),
          audienceScore: audienceScore.toString(),
          contentScore: contentScore.toString(),
          budgetScore: budgetScore.toString(),
          overallScore: overallScore.toString(),
        };

        return this.createInfluencerMatch(matchData);
      })
    );

    return matches;
  },

  // Score calculation functions
  calculatePerformanceScore(influencer: schema.Influencer, criteria: schema.InfluencerCriteria): number {
    // Enhanced score calculation based on subscribers, views, and engagement rate
    // Each factor is weighted to better reflect their importance
    
    // SUBSCRIBER SCORE (0-10)
    // Check if influencer meets minimum subscriber criteria
    // (We should never get here if they don't, but double check as a fallback)
    const subscriberCount = Number(influencer.subscribers);
    const minSubscriberCount = Number(criteria.minSubscribers);
    
    // If influencer doesn't meet minimum criteria, return a very low score
    if (subscriberCount < minSubscriberCount) {
      console.error(`Influencer ${influencer.displayName} has only ${subscriberCount} subscribers, below minimum ${minSubscriberCount}`);
      return 0; // This ensures they get filtered out
    }
    
    // Calculate as a ratio of actual to minimum, but cap at 10
    const subscriberRatio = subscriberCount / minSubscriberCount;
    const subscriberScore = Math.min(10, subscriberRatio * 3); // Multiplier makes score reach 10 faster
    
    console.log(`Subscribers score for ${influencer.displayName}: ${subscriberScore} (${subscriberCount} / ${minSubscriberCount})`)
    
    // ENGAGEMENT RATE SCORE (0-10)
    // Higher score for engagement rate that exceeds minimum criteria
    // Engagement rate is one of the most crucial metrics, so we weight it heavily
    const engagementRatio = Number(influencer.engagementRate) / Number(criteria.minEngagementRate);
    const engagementScore = Math.min(10, engagementRatio * 4); // Higher multiplier for more importance
    
    // VIEW COUNT SCORE (0-10)
    // Logarithmic scale for views since they can vary widely
    // Average views per video is important for reach prediction
    const avgViewsPerVideo = influencer.avgViews;
    // Using log10 with normalization to get a 0-10 score
    // 1,000 views → ~3, 10,000 → ~4, 100,000 → ~5, 1M → ~6, 10M → ~7
    const viewScore = Math.min(10, 3 + Math.log10(Math.max(1000, avgViewsPerVideo)) - 3);
    
    // CONSISTENCY SCORE
    // This would ideally be based on the ratio of avgViews to totalViews/videoCount
    // But we'll approximate using the ratio of avgViews to subscribers as a proxy
    const viewToSubRatio = avgViewsPerVideo / Math.max(1, influencer.subscribers);
    const consistencyScore = Math.min(10, viewToSubRatio * 100); // Scale to 0-10
    
    // WEIGHTED SCORE CALCULATION
    // Weight factors based on their importance to campaign success:
    // - Engagement rate is most important (highest correlation with conversion)
    // - View count is next (indicates actual reach)
    // - Subscribers third (potential audience)
    // - Consistency is also important (reliability indicator)
    const weightedScore = (
      (engagementScore * 0.4) +  // 40% weight to engagement rate
      (viewScore * 0.3) +        // 30% weight to view count
      (subscriberScore * 0.2) +  // 20% weight to subscriber count
      (consistencyScore * 0.1)   // 10% weight to consistency
    );
    
    // Return score with 2 decimal precision
    return Number(weightedScore.toFixed(2));
  },

  calculateAudienceScore(influencer: schema.Influencer, audience: schema.TargetAudience): number {
    // Initialize base score and factor tracking
    let score = 0;
    let factorsConsidered = 0;
    
    // Location matching (worth up to 2.5 points)
    if (influencer.location) {
      const targetLocations = audience.locations as string[];
      if (Array.isArray(targetLocations) && targetLocations.length > 0) {
        // Check if influencer's location is in the target locations
        // Using some substring matching to be more flexible
        const locationMatches = targetLocations.some(location => 
          influencer.location?.toLowerCase().includes(location.toLowerCase())
        );
        
        if (locationMatches) {
          score += 2.5;
        }
        factorsConsidered++;
      }
    }
    
    // Interest alignment (worth up to 5 points - most important factor)
    // Compare tags with target interests
    const influencerTags = influencer.tags as string[];
    const targetInterests = audience.interests as string[];
    
    if (Array.isArray(influencerTags) && Array.isArray(targetInterests) && 
        influencerTags.length > 0 && targetInterests.length > 0) {
      
      // Look for tag/interest matches (case insensitive)
      const matchingInterests = targetInterests.filter(interest => 
        influencerTags.some(tag => 
          tag.toLowerCase().includes(interest.toLowerCase()) || 
          interest.toLowerCase().includes(tag.toLowerCase())
        )
      );
      
      // Calculate match percentage based on interests
      // The more target interests matched, the better
      const interestMatchPercentage = matchingInterests.length / targetInterests.length;
      
      // Heavy weight on interest matching (up to 5 points)
      const interestScore = interestMatchPercentage * 5;
      score += interestScore;
      factorsConsidered++;
      
      // Debugging
      console.log(`Audience interest matching for influencer ${influencer.displayName}:`, {
        influencerTags,
        targetInterests,
        matchingInterests,
        interestMatchPercentage,
        interestScore
      });
    }
    
    // Gender matching (worth up to 2.5 points)
    // If gender is specified and there's a match, add points
    if (audience.gender && audience.gender !== 'all') {
      // For a real implementation, we would need demographic data from the influencer
      // For now, we can use a heuristic based on their content/tags
      const genderRelevantTags = influencer.tags as string[];
      
      if (Array.isArray(genderRelevantTags) && genderRelevantTags.length > 0) {
        // Check if tags suggest gender-specific content
        // This is a very basic approximation - in a real system we'd have actual demographic data
        const femaleIndicators = ['women', 'woman', 'female', 'girl', 'girls', 'ladies', 'makeup', 'beauty'];
        const maleIndicators = ['men', 'man', 'male', 'boy', 'boys', 'guys', 'gentlemen'];
        
        const hasFemaleIndicators = genderRelevantTags.some(tag => 
          femaleIndicators.some(indicator => tag.toLowerCase().includes(indicator))
        );
        
        const hasMaleIndicators = genderRelevantTags.some(tag => 
          maleIndicators.some(indicator => tag.toLowerCase().includes(indicator))
        );
        
        // Add score if there's alignment with target gender
        if ((audience.gender === 'female' && hasFemaleIndicators) || 
            (audience.gender === 'male' && hasMaleIndicators)) {
          score += 2.5;
        }
        factorsConsidered++;
      }
    }
    
    // If we didn't have any factors to consider, give a neutral-low score
    // This is different from before - we're more conservative with no data
    if (factorsConsidered === 0) {
      return 5.0; // Neutral score
    }
    
    // Normalize score based on factors considered, ensuring it's in 0-10 range
    // More factors means more confidence in the score
    const maxPossibleScore = factorsConsidered * 2.5;
    const normalizedScore = (score / maxPossibleScore) * 10;
    
    return Math.min(10, Math.max(0, normalizedScore));
  },

  calculateContentScore(influencer: schema.Influencer, criteria: schema.InfluencerCriteria): number {
    // Calculate category matching - this is the MOST important factor
    const influencerCategories = influencer.categories as number[];
    const targetCategories = criteria.categories as number[];
    
    let categoryScore = 0;
    let hasExactCategoryMatch = false;
    
    if (Array.isArray(influencerCategories) && Array.isArray(targetCategories) && 
        influencerCategories.length > 0 && targetCategories.length > 0) {
      
      // Count matching categories
      const matchingCategories = influencerCategories.filter(category => 
        targetCategories.includes(category)
      );
      
      // Check if we have any exact category matches
      hasExactCategoryMatch = matchingCategories.length > 0;
      
      // Calculate match percentage - how many of our target categories are matched
      const matchPercentage = matchingCategories.length / targetCategories.length;
      
      // Heavily weight category matching - this is critical
      categoryScore = matchPercentage * 10; // Scale to 0-10
      
      // Debug logging
      console.log(`Category matching for influencer ${influencer.displayName}:`, {
        influencerCategories,
        targetCategories,
        matchingCategories,
        matchPercentage,
        categoryScore,
        hasExactCategoryMatch
      });
    }
    
    // Calculate keyword matching
    const influencerTags = influencer.tags as string[];
    const campaignKeywords = criteria.keywords as string[];
    
    let keywordScore = 0;
    
    if (Array.isArray(influencerTags) && Array.isArray(campaignKeywords) &&
        influencerTags.length > 0 && campaignKeywords.length > 0) {
      
      // Count tags that match any of the keywords (case insensitive)
      const matchingTags = influencerTags.filter(tag => 
        campaignKeywords.some(keyword => 
          tag.toLowerCase().includes(keyword.toLowerCase()) || 
          keyword.toLowerCase().includes(tag.toLowerCase())
        )
      );
      
      // Calculate match percentage - focused on how many keywords we match
      const matchPercentage = matchingTags.length / campaignKeywords.length;
      keywordScore = matchPercentage * 10; // Scale to 0-10
      
      // Debug logging
      console.log(`Keyword matching for influencer ${influencer.displayName}:`, {
        influencerTags,
        campaignKeywords,
        matchingTags,
        matchPercentage,
        keywordScore
      });
    }
    
    // CRITICAL CHANGE: If no category match, severely penalize the score
    // This ensures influencers who don't match ANY of our categories are ranked much lower
    if (!hasExactCategoryMatch && targetCategories.length > 0 && influencerCategories.length > 0) {
      // Still give some weight to keyword matching, but overall score should be low
      const penalizedScore = keywordScore * 0.3; // Only 30% of keyword score counts
      
      console.log(`Penalizing ${influencer.displayName} for no category match. Final score: ${penalizedScore}`);
      
      // Return the penalized score - max of 3.0
      return Math.min(3.0, penalizedScore);
    }
    
    // Combine scores with more weight to category matching (60%) than keywords (40%)
    const combinedScore = (categoryScore * 0.6) + (keywordScore * 0.4);
    
    // If no meaningful data for comparison, return a neutral-low score
    if ((influencerCategories?.length === 0 || targetCategories?.length === 0) &&
        (influencerTags?.length === 0 || campaignKeywords?.length === 0)) {
      return 5.0; // Neutral score
    }
    
    // Return combined score, ensuring it's in 0-10 range
    return Number(Math.min(10, Math.max(0, combinedScore)).toFixed(2));
  },

  calculateBudgetScore(influencer: schema.Influencer, campaign: schema.Campaign): number {
    // Calculate cost effectiveness
    // Higher scores for influencers whose cost is appropriate for the campaign budget
    if (!influencer.estimatedCost) return 5; // Neutral score if no cost data
    
    const budgetPerInfluencer = Number(campaign.budget) / campaign.influencersNeeded;
    const costRatio = budgetPerInfluencer / Number(influencer.estimatedCost);
    
    // Score higher when cost is close to or less than the budget per influencer
    if (costRatio >= 1.5) return 10; // Great value
    if (costRatio >= 1) return 9; // Good value
    if (costRatio >= 0.8) return 8; // Reasonable
    if (costRatio >= 0.6) return 7; // Slightly expensive
    if (costRatio >= 0.4) return 5; // Expensive
    return 3; // Very expensive
  },
};
