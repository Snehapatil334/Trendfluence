import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import * as schema from "@shared/schema";
import { setupAuth } from "./auth";
import { youtubeService } from "./services/youtube";
import { db } from "@db";
import { eq } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  // Add CORS headers for local development
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', req.headers.origin || 'http://localhost:5000');
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    
    next();
  });
  
  // Setup authentication routes
  setupAuth(app);
  
  // API prefix
  const apiPrefix = "/api";

  // Categories routes
  app.get(`${apiPrefix}/categories`, async (req, res) => {
    try {
      const categories = await storage.getAllCategories();
      return res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      return res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Campaigns routes
  app.get(`${apiPrefix}/campaigns`, async (req, res) => {
    try {
      const campaigns = await storage.getAllCampaigns();
      return res.json(campaigns);
    } catch (error) {
      console.error("Error fetching campaigns:", error);
      return res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  app.get(`${apiPrefix}/campaigns/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }

      const campaign = await storage.getCampaignById(id);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      return res.json(campaign);
    } catch (error) {
      console.error("Error fetching campaign:", error);
      return res.status(500).json({ message: "Failed to fetch campaign" });
    }
  });

  app.post(`${apiPrefix}/campaigns`, async (req, res) => {
    try {
      // Validate the request body against the schema
      const campaignData = schema.insertCampaignSchema.parse(req.body);
      
      // Create the campaign
      const campaign = await storage.createCampaign(campaignData);
      
      return res.status(201).json(campaign);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid campaign data", errors: error.errors });
      }
      console.error("Error creating campaign:", error);
      return res.status(500).json({ message: "Failed to create campaign" });
    }
  });

  app.patch(`${apiPrefix}/campaigns/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }

      // Get existing campaign to make sure it exists
      const existingCampaign = await storage.getCampaignById(id);
      if (!existingCampaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Update the campaign
      const updatedCampaign = await storage.updateCampaign(id, req.body);
      
      return res.json(updatedCampaign);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid campaign data", errors: error.errors });
      }
      console.error("Error updating campaign:", error);
      return res.status(500).json({ message: "Failed to update campaign" });
    }
  });
  
  app.delete(`${apiPrefix}/campaigns/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }

      // Get existing campaign to make sure it exists
      const existingCampaign = await storage.getCampaignById(id);
      if (!existingCampaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Delete the campaign and all related data
      const deletedCampaign = await storage.deleteCampaign(id);
      
      return res.status(200).json({ message: "Campaign deleted successfully", campaign: deletedCampaign });
    } catch (error) {
      console.error("Error deleting campaign:", error);
      return res.status(500).json({ message: "Failed to delete campaign" });
    }
  });

  // Target audience routes
  app.get(`${apiPrefix}/campaigns/:id/target-audience`, async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }

      const targetAudience = await storage.getTargetAudienceByCampaignId(campaignId);
      if (!targetAudience) {
        return res.status(404).json({ message: "Target audience not found for this campaign" });
      }

      return res.json(targetAudience);
    } catch (error) {
      console.error("Error fetching target audience:", error);
      return res.status(500).json({ message: "Failed to fetch target audience" });
    }
  });

  app.post(`${apiPrefix}/campaigns/:id/target-audience`, async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }

      // Check if campaign exists
      const campaign = await storage.getCampaignById(campaignId);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Check if target audience already exists
      const existingAudience = await storage.getTargetAudienceByCampaignId(campaignId);
      if (existingAudience) {
        // Update existing audience
        const updatedAudience = await storage.updateTargetAudience(existingAudience.id, {
          ...req.body,
          campaignId
        });
        return res.json(updatedAudience);
      } else {
        // Create new audience
        const audienceData = schema.insertTargetAudienceSchema.parse({
          ...req.body,
          campaignId
        });
        const audience = await storage.createTargetAudience(audienceData);
        return res.status(201).json(audience);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid target audience data", errors: error.errors });
      }
      console.error("Error creating/updating target audience:", error);
      return res.status(500).json({ message: "Failed to create/update target audience" });
    }
  });

  // Influencer criteria routes
  app.get(`${apiPrefix}/campaigns/:id/influencer-criteria`, async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }

      const influencerCriteria = await storage.getInfluencerCriteriaByCampaignId(campaignId);
      if (!influencerCriteria) {
        return res.status(404).json({ message: "Influencer criteria not found for this campaign" });
      }

      return res.json(influencerCriteria);
    } catch (error) {
      console.error("Error fetching influencer criteria:", error);
      return res.status(500).json({ message: "Failed to fetch influencer criteria" });
    }
  });

  app.post(`${apiPrefix}/campaigns/:id/influencer-criteria`, async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }

      // Check if campaign exists
      const campaign = await storage.getCampaignById(campaignId);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Check if criteria already exists
      const existingCriteria = await storage.getInfluencerCriteriaByCampaignId(campaignId);
      if (existingCriteria) {
        // Update existing criteria
        const updatedCriteria = await storage.updateInfluencerCriteria(existingCriteria.id, {
          ...req.body,
          campaignId
        });
        return res.json(updatedCriteria);
      } else {
        // Create new criteria
        const criteriaData = schema.insertInfluencerCriteriaSchema.parse({
          ...req.body,
          campaignId
        });
        const criteria = await storage.createInfluencerCriteria(criteriaData);
        return res.status(201).json(criteria);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid influencer criteria data", errors: error.errors });
      }
      console.error("Error creating/updating influencer criteria:", error);
      return res.status(500).json({ message: "Failed to create/update influencer criteria" });
    }
  });

  // Influencer routes
  app.get(`${apiPrefix}/influencers`, async (req, res) => {
    try {
      const search = req.query.search as string | undefined;
      
      if (search) {
        const influencers = await storage.searchInfluencers(search);
        return res.json(influencers);
      } else {
        const influencers = await storage.getAllInfluencers();
        return res.json(influencers);
      }
    } catch (error) {
      console.error("Error fetching influencers:", error);
      return res.status(500).json({ message: "Failed to fetch influencers" });
    }
  });

  app.get(`${apiPrefix}/influencers/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid influencer ID" });
      }

      const influencer = await storage.getInfluencerById(id);
      if (!influencer) {
        return res.status(404).json({ message: "Influencer not found" });
      }

      return res.json(influencer);
    } catch (error) {
      console.error("Error fetching influencer:", error);
      return res.status(500).json({ message: "Failed to fetch influencer" });
    }
  });

  // Matching routes
  app.post(`${apiPrefix}/campaigns/:id/match`, async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }

      // Find matching influencers
      const matches = await storage.findMatchingInfluencers(campaignId);
      return res.status(200).json(matches);
    } catch (error) {
      console.error("Error matching influencers:", error);
      return res.status(500).json({ message: "Failed to match influencers" });
    }
  });

  app.get(`${apiPrefix}/campaigns/:id/matches`, async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }

      // Get all matches for the campaign
      const matches = await storage.getInfluencerMatchesByCampaignId(campaignId);
      return res.json(matches);
    } catch (error) {
      console.error("Error fetching matches:", error);
      return res.status(500).json({ message: "Failed to fetch matches" });
    }
  });

  app.get(`${apiPrefix}/campaigns/:id/top-matches`, async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }

      const limit = parseInt(req.query.limit as string || "3");

      // Get top matches for the campaign
      const matches = await storage.getTopInfluencerMatches(campaignId, limit);
      return res.json(matches);
    } catch (error) {
      console.error("Error fetching top matches:", error);
      return res.status(500).json({ message: "Failed to fetch top matches" });
    }
  });

  // YouTube API integration routes
  app.get(`${apiPrefix}/youtube/search`, async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Query parameter 'q' is required" });
      }

      const maxResults = req.query.maxResults ? parseInt(req.query.maxResults as string) : 5;
      const results = await youtubeService.searchChannels(query, maxResults);
      return res.json(results);
    } catch (error) {
      console.error("Error searching YouTube channels:", error);
      return res.status(500).json({ message: "Failed to search YouTube channels" });
    }
  });

  app.get(`${apiPrefix}/youtube/channel/:id`, async (req, res) => {
    try {
      const channelId = req.params.id;
      const details = await youtubeService.getChannelDetails(channelId);
      
      if (!details) {
        return res.status(404).json({ message: "Channel not found" });
      }
      
      return res.json(details);
    } catch (error) {
      console.error("Error fetching YouTube channel details:", error);
      return res.status(500).json({ message: "Failed to fetch YouTube channel details" });
    }
  });

  app.post(`${apiPrefix}/youtube/fetch-and-store`, async (req, res) => {
    try {
      const { channelId, categoryIds } = req.body;
      
      if (!channelId) {
        return res.status(400).json({ message: "channelId is required" });
      }
      
      const influencer = await youtubeService.fetchAndStoreInfluencer(
        channelId, 
        categoryIds || []
      );
      
      if (!influencer) {
        return res.status(404).json({ message: "Failed to fetch and store influencer" });
      }
      
      return res.status(201).json(influencer);
    } catch (error) {
      console.error("Error fetching and storing influencer:", error);
      return res.status(500).json({ message: "Failed to fetch and store influencer" });
    }
  });

  app.post(`${apiPrefix}/youtube/search-and-store`, async (req, res) => {
    try {
      const { query, categoryIds, maxResults } = req.body;
      
      if (!query) {
        return res.status(400).json({ message: "query is required" });
      }
      
      const influencers = await youtubeService.searchAndStoreChannels(
        query, 
        categoryIds || [], 
        maxResults || 5
      );
      
      return res.status(201).json(influencers);
    } catch (error) {
      console.error("Error searching and storing channels:", error);
      return res.status(500).json({ message: "Failed to search and store channels" });
    }
  });

  // Enhanced campaign matching with YouTube integration
  app.post(`${apiPrefix}/campaigns/:id/match-with-youtube`, async (req, res) => {
    try {
      const campaignId = parseInt(req.params.id);
      if (isNaN(campaignId)) {
        return res.status(400).json({ message: "Invalid campaign ID" });
      }

      // Get campaign data for search
      const campaign = await storage.getCampaignById(campaignId);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Get criteria to determine YouTube search query
      const criteria = await storage.getInfluencerCriteriaByCampaignId(campaignId);
      if (!criteria) {
        return res.status(404).json({ message: "Campaign criteria not found" });
      }

      // Clear existing matches for this campaign to start fresh
      await db.delete(schema.influencerMatches)
        .where(eq(schema.influencerMatches.campaignId, campaignId));
      console.log(`Cleared existing matches for campaign ${campaignId}`);

      // Extract minimum subscriber count requirement
      const minSubscribers = Number(criteria.minSubscribers);
      console.log(`Campaign requires minimum ${minSubscribers.toLocaleString()} subscribers`);

      // Fetch categories for this campaign
      const categoryIds = criteria.categories as number[] || [];
      
      // Get target audience data for more precise search query
      const targetAudience = await storage.getTargetAudienceByCampaignId(campaignId);
      
      // Check if this is a beauty or fashion campaign
      const isBeautyOrFashion = categoryIds.includes(7) || categoryIds.includes(10);
      console.log(`Campaign is beauty/fashion: ${isBeautyOrFashion}`);
      
      // Construct search queries differently based on campaign type
      let searchQueries = [];
      
      // Primary query based on campaign details
      let primaryTerms = [campaign.name];
      
      // Add campaign type if available
      if (campaign.campaignType) {
        primaryTerms.push(campaign.campaignType);
      }
      
      // Add content types if available
      if (Array.isArray(campaign.contentTypes) && campaign.contentTypes.length > 0) {
        primaryTerms.push(...campaign.contentTypes.slice(0, 2)); // Add up to 2 content types
      }
      
      // Add audience interests if available
      if (targetAudience && Array.isArray(targetAudience.interests) && targetAudience.interests.length > 0) {
        primaryTerms.push(...targetAudience.interests.slice(0, 2)); // Add up to 2 interests
      }
      
      // If this is a beauty/fashion campaign, explicitly add those terms
      if (isBeautyOrFashion) {
        if (!primaryTerms.some(term => 
              typeof term === 'string' && 
              (term.toLowerCase().includes('beauty') || term.toLowerCase().includes('makeup')))) {
          primaryTerms.push('beauty makeup');
        }
      }
      
      // Build primary query string
      const primaryQuery = primaryTerms.slice(0, 4).join(' ');
      searchQueries.push(primaryQuery);
      
      // Add specialty queries for beauty/fashion with high subscriber requirements
      if (isBeautyOrFashion && minSubscribers >= 500000) {
        // Add more targeted searchesd for high-subscriber beauty influencers
        searchQueries.push(
          "popular beauty influencer", 
          "top makeup youtuber millions",
          "beauty guru million subscribers"
        );
      }
      
      // Determine how many results to fetch per query
      const resultsPerQuery = Math.max(3, Math.ceil(15 / searchQueries.length));
      const allInfluencers: schema.Influencer[] = [];
      
      // Run all search queries and collect influencers
      console.log(`Running ${searchQueries.length} different YouTube search queries...`);
      for (const query of searchQueries) {
        console.log(`Executing YouTube search for: "${query}"`);
        const queryInfluencers = await youtubeService.searchAndStoreChannels(
          query,
          categoryIds,
          resultsPerQuery,
          minSubscribers
        );
        
        console.log(`Found ${queryInfluencers.length} influencers for query "${query}"`);
        
        // Add to our collection, avoiding duplicates
        for (const influencer of queryInfluencers) {
          if (!allInfluencers.some(existing => existing.id === influencer.id)) {
            allInfluencers.push(influencer);
          }
        }
      }
      
      console.log(`Added/updated ${allInfluencers.length} total influencers from YouTube`);
      
      // If we still don't have enough matches, try with a slightly lower subscriber threshold
      if (allInfluencers.length < 3 && minSubscribers > 300000) {
        const lowerThreshold = Math.floor(minSubscribers * 0.7); // 70% of original
        console.log(`Trying with lower subscriber threshold (${lowerThreshold.toLocaleString()})...`);
        
        const backupQuery = primaryQuery + " youtuber";
        const backupInfluencers = await youtubeService.searchAndStoreChannels(
          backupQuery,
          categoryIds,
          5,
          lowerThreshold
        );
        
        // Add any non-duplicate influencers
        for (const influencer of backupInfluencers) {
          if (!allInfluencers.some(existing => existing.id === influencer.id)) {
            console.log(`Adding backup influencer: ${influencer.displayName} (${influencer.subscribers} subscribers)`);
            allInfluencers.push(influencer);
          }
        }
      }
      
      // Run matching algorithm after adding all the new influencers
      const matches = await storage.findMatchingInfluencers(campaignId);
      console.log(`Found ${matches.length} matching influencers for campaign ${campaignId}`);
      
      // Return enhanced response with YouTube search metadata
      return res.status(200).json({
        matches,
        meta: {
          searchQueries: searchQueries,
          subscriberRequirement: minSubscribers,
          youtubeChannelsAdded: allInfluencers.length,
          totalInfluencersMatched: matches.length,
          searchTimestamp: new Date().toISOString()
        }
      });
    } catch (error) {
      console.error("Error matching with YouTube:", error);
      return res.status(500).json({ message: "Failed to match with YouTube" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
