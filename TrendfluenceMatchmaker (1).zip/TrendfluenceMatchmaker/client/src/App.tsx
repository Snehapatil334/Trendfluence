import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import Dashboard from "@/pages/dashboard";
import Campaigns from "@/pages/campaigns";
import NewCampaign from "@/pages/campaigns/new";
import EditCampaign from "@/pages/campaigns/edit";
import CampaignDetails from "@/pages/campaign-details";
import Influencers from "@/pages/influencers";
import InfluencerDetails from "@/pages/influencer-details";
import Analytics from "@/pages/analytics";
import CampaignAnalytics from "@/pages/analytics/campaigns";
import AudienceAnalytics from "@/pages/analytics/audience";
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { useAuth } from "@/hooks/use-auth";

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex pt-16">
      <Sidebar />
      <main className="flex-1 ml-16 lg:ml-56 px-4 py-6 lg:px-8 overflow-auto">
        <div className="max-w-7xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}

function AppRoutes() {
  const { user } = useAuth();

  return (
    <>
      {user && <Header />}
      <Switch>
        <Route path="/auth" component={AuthPage} />
        
        <ProtectedRoute path="/">
          <Layout>
            <Dashboard />
          </Layout>
        </ProtectedRoute>
        
        <ProtectedRoute path="/campaigns">
          <Layout>
            <Campaigns />
          </Layout>
        </ProtectedRoute>
        
        <ProtectedRoute path="/campaigns/new">
          <Layout>
            <NewCampaign />
          </Layout>
        </ProtectedRoute>
        
        <ProtectedRoute path="/campaigns/edit/:id">
          <Layout>
            <EditCampaign />
          </Layout>
        </ProtectedRoute>
        
        <ProtectedRoute path="/campaigns/:id">
          <Layout>
            <CampaignDetails />
          </Layout>
        </ProtectedRoute>
        
        <ProtectedRoute path="/influencers">
          <Layout>
            <Influencers />
          </Layout>
        </ProtectedRoute>
        
        <ProtectedRoute path="/influencers/:id">
          <Layout>
            <InfluencerDetails />
          </Layout>
        </ProtectedRoute>
        
        <ProtectedRoute path="/analytics">
          <Layout>
            <Analytics />
          </Layout>
        </ProtectedRoute>
        
        <ProtectedRoute path="/analytics/campaigns">
          <Layout>
            <CampaignAnalytics />
          </Layout>
        </ProtectedRoute>
        
        <ProtectedRoute path="/analytics/audience">
          <Layout>
            <AudienceAnalytics />
          </Layout>
        </ProtectedRoute>
        
        <Route>
          {user ? (
            <Layout>
              <NotFound />
            </Layout>
          ) : (
            <NotFound />
          )}
        </Route>
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <AppRoutes />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
