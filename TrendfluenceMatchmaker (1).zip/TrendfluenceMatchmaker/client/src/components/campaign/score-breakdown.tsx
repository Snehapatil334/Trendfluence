import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip as RechartsTooltip } from "recharts";
import { Campaign, Influencer } from "@shared/schema";

// Define the enhanced InfluencerMatch type that includes the influencer field
interface EnhancedInfluencerMatch {
  id: number;
  campaignId: number;
  influencerId: number;
  performanceScore: string;
  audienceScore: string;
  contentScore: string;
  budgetScore: string;
  overallScore: string;
  status: string;
  createdAt: string | Date;
  influencer: Influencer & {
    tags: string[];
    avgViews: number;
    estimatedCost: number;
  };
}

interface ScoreBreakdownProps {
  campaignId: number;
}

export default function ScoreBreakdown({ campaignId }: ScoreBreakdownProps) {
  const { data: campaign } = useQuery<Campaign>({
    queryKey: [`/api/campaigns/${campaignId}`],
    enabled: !!campaignId,
  });

  const { data: topMatches, isLoading: isLoadingMatches } = useQuery<EnhancedInfluencerMatch[]>({
    queryKey: [`/api/campaigns/${campaignId}/top-matches`],
    enabled: !!campaignId,
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Calculate budget stats
  const totalBudget = campaign?.budget ? Number(campaign.budget) : 0;
  
  let allocatedBudget = 0;
  if (topMatches && topMatches.length > 0) {
    allocatedBudget = topMatches.reduce((sum: number, match: EnhancedInfluencerMatch) => {
      return sum + Number(match.influencer.estimatedCost || 0);
    }, 0);
  }

  const remainingBudget = totalBudget - allocatedBudget;
  const allocationPercentage = (allocatedBudget / totalBudget) * 100;
  const remainingPercentage = 100 - allocationPercentage;

  // Prepare data for score breakdown chart
  const scoreFactors = [
    { name: "Performance", weight: "30%", score: topMatches?.[0]?.performanceScore || 0 },
    { name: "Audience", weight: "30%", score: topMatches?.[0]?.audienceScore || 0 },
    { name: "Content", weight: "30%", score: topMatches?.[0]?.contentScore || 0 },
    { name: "Budget", weight: "10%", score: topMatches?.[0]?.budgetScore || 0 },
  ];

  // Overall score (average of top match)
  const overallScore = topMatches?.[0]?.overallScore || 0;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 mb-6">
      <div className="border-b border-slate-200 px-6 py-4">
        <h2 className="font-semibold text-lg">Match Score Breakdown</h2>
      </div>
      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <div className="mb-4">
              <h3 className="font-medium mb-3">Top 3 Influencers</h3>
              <div className="space-y-3">
                {isLoadingMatches ? (
                  <>
                    {[1, 2, 3].map(i => (
                      <div key={i} className="flex items-center">
                        <Skeleton className="w-10 h-10 rounded-full mr-3" />
                        <div className="flex-1">
                          <div className="flex justify-between">
                            <div>
                              <Skeleton className="h-4 w-32 mb-1" />
                              <Skeleton className="h-3 w-40" />
                            </div>
                            <div className="text-right">
                              <Skeleton className="h-4 w-10 mb-1 ml-auto" />
                              <Skeleton className="h-3 w-20 ml-auto" />
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </>
                ) : (
                  <>
                    {topMatches?.map((match) => (
                      <div key={match.influencerId} className="flex items-center">
                        <img 
                          src={typeof match.influencer.profileImageUrl === 'string' ? match.influencer.profileImageUrl : '/assets/placeholder-profile.png'} 
                          alt={typeof match.influencer.displayName === 'string' ? match.influencer.displayName : 'Influencer'} 
                          className="w-10 h-10 rounded-full mr-3 object-cover" 
                        />
                        <div className="flex-1">
                          <div className="flex justify-between">
                            <div>
                              <h4 className="font-medium">{match.influencer.channelTitle}</h4>
                              <div className="flex items-center text-xs text-slate-500">
                                <span>{(match.influencer.subscribers / 1000).toFixed(0)}K subscribers</span>
                                <span className="mx-1">•</span>
                                <span>{match.influencer.engagementRate}% engagement</span>
                              </div>
                            </div>
                            <div className="text-right">
                              <span className={`font-medium ${Number(match.overallScore) >= 90 ? 'text-secondary-500' : Number(match.overallScore) >= 80 ? 'text-accent-500' : 'text-slate-500'}`}>
                                {Math.round(Number(match.overallScore))}%
                              </span>
                              <div className="text-xs text-slate-500">Match Score</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </div>
            
            <div>
              <h3 className="font-medium mb-3">Budget Distribution</h3>
              <div className="bg-slate-50 rounded-lg p-4">
                {campaign ? (
                  <>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Total Budget</span>
                      <span className="font-medium">{formatCurrency(Number(campaign.budget))}</span>
                    </div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Top 3 Influencers</span>
                      <span className="font-medium">{formatCurrency(allocatedBudget)}</span>
                    </div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Remaining for Others</span>
                      <span className="font-medium">{formatCurrency(remainingBudget)}</span>
                    </div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Estimated Reach</span>
                      <span className="font-medium">
                        {topMatches ? (
                          `${(topMatches.reduce((sum, match) => sum + match.influencer.avgViews, 0) / 1000000).toFixed(1)}M+ views`
                        ) : (
                          'Calculating...'
                        )}
                      </span>
                    </div>
                    <Progress value={allocationPercentage} className="h-1.5 mt-3" />
                    <div className="flex justify-between text-xs text-slate-500 mt-1">
                      <span>{allocationPercentage.toFixed(1)}% allocated</span>
                      <span>{remainingPercentage.toFixed(1)}% remaining</span>
                    </div>
                  </>
                ) : (
                  <>
                    {[1, 2, 3, 4].map(i => (
                      <div key={i} className="flex justify-between text-sm mb-2">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-4 w-20" />
                      </div>
                    ))}
                    <Skeleton className="h-1.5 w-full mt-3" />
                    <div className="flex justify-between mt-1">
                      <Skeleton className="h-3 w-24" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium mb-3">Matching Algorithm Factors</h3>
            <div className="chart-container bg-slate-50 rounded-lg p-4">
              {topMatches ? (
                <div className="h-full flex flex-col justify-between">
                  <div>
                    {scoreFactors.map((factor, idx) => (
                      <div key={idx}>
                        <div className="flex justify-between items-center mb-2">
                          <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-sm ${
                              idx === 0 ? 'bg-primary-500' :
                              idx === 1 ? 'bg-secondary-500' :
                              idx === 2 ? 'bg-accent-500' : 'bg-slate-500'
                            }`}></div>
                            <span className="text-sm">{factor.name} Score ({factor.weight})</span>
                          </div>
                          <span className="text-sm font-medium">{Number(factor.score).toFixed(1)}/10</span>
                        </div>
                        <Progress 
                          value={Number(factor.score) * 10} 
                          className={`h-2 mb-3 ${
                            idx === 0 ? 'bg-primary-100' :
                            idx === 1 ? 'bg-secondary-100/50' :
                            idx === 2 ? 'bg-accent-100/50' : 'bg-slate-100'
                          }`}
                          indicatorClassName={
                            idx === 0 ? 'bg-primary-500' :
                            idx === 1 ? 'bg-secondary-500' :
                            idx === 2 ? 'bg-accent-500' : 'bg-slate-500'
                          }
                        />
                      </div>
                    ))}
                  </div>
                  
                  <div>
                    <div className="border-t border-slate-200 pt-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Overall Match Score</span>
                        <span className="text-lg font-semibold text-primary-600">{(Number(overallScore) / 10).toFixed(1)}/10</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">Based on the weighted average of all scoring factors</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col justify-between">
                  <div>
                    {[1, 2, 3, 4].map(i => (
                      <div key={i} className="mb-3">
                        <div className="flex justify-between items-center mb-2">
                          <Skeleton className="h-4 w-40" />
                          <Skeleton className="h-4 w-16" />
                        </div>
                        <Skeleton className="h-2 w-full" />
                      </div>
                    ))}
                  </div>
                  
                  <div>
                    <div className="border-t border-slate-200 pt-3">
                      <div className="flex justify-between items-center">
                        <Skeleton className="h-4 w-40" />
                        <Skeleton className="h-6 w-20" />
                      </div>
                      <Skeleton className="h-3 w-full mt-2" />
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="mt-4">
              <h3 className="font-medium mb-3">Topic Alignment</h3>
              <div className="bg-slate-50 rounded-lg p-4">
                {isLoadingMatches ? (
                  <div className="flex flex-wrap gap-2">
                    {[1, 2, 3, 4, 5, 6].map(i => (
                      <Skeleton key={i} className="h-8 w-24 rounded-md" />
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {topMatches && topMatches[0]?.influencer.tags.map((tag: string, idx: number) => {
                      const matchPercent = 95 - (idx * 3); // Simulated decreasing match percentages
                      return (
                        <div 
                          key={tag} 
                          className={`${idx < 3 ? 'bg-primary-50 text-primary-700' : 'bg-slate-100 text-slate-700'} px-2 py-1 rounded-md text-sm`}
                        >
                          <span className="font-medium">{tag}</span>
                          <span className="text-xs ml-1">{matchPercent}% match</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
