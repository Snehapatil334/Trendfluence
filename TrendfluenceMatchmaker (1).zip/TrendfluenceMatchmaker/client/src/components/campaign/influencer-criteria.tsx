import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { Checkbox } from "@/components/ui/checkbox";
import { Category } from "@shared/schema";

const formSchema = z.object({
  categories: z.array(z.number()),
  minSubscribers: z.coerce.number().min(1000),
  minEngagementRate: z.coerce.number().min(0.1),
  keywords: z.string().min(3, "Please provide at least one keyword"),
});

export type InfluencerCriteriaFormValues = z.infer<typeof formSchema>;

interface InfluencerCriteriaProps {
  onSubmit: (data: InfluencerCriteriaFormValues) => void;
  defaultValues?: Partial<InfluencerCriteriaFormValues>;
}

export default function InfluencerCriteria({ onSubmit, defaultValues }: InfluencerCriteriaProps) {
  // Fetch categories
  const { data: categories, isLoading } = useQuery({
    queryKey: ['/api/categories'],
  });

  const form = useForm<InfluencerCriteriaFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      categories: [],
      minSubscribers: 10000,
      minEngagementRate: 2,
      keywords: "plant-based, protein, organic, workout, fitness, eco-friendly",
      ...defaultValues,
    }
  });

  // Parse keywords from comma-separated string to array and back
  const keywordsToString = (keywords: string[]): string => {
    return keywords.join(", ");
  };

  const stringToKeywords = (keywordsString: string): string[] => {
    return keywordsString.split(",").map(kw => kw.trim()).filter(kw => kw);
  };

  const handleSubmit = (data: InfluencerCriteriaFormValues) => {
    // Convert keywords string to array and ensure minEngagementRate is a string
    const formattedData = {
      ...data,
      keywords: stringToKeywords(data.keywords),
      minEngagementRate: String(data.minEngagementRate)
    };
    
    console.log("Submitting influencer criteria:", formattedData);
    onSubmit(formattedData as any);
  };

  // Toggle category selection
  const toggleCategory = (categoryId: number) => {
    const currentCategories = form.getValues().categories;
    if (currentCategories.includes(categoryId)) {
      form.setValue("categories", currentCategories.filter(id => id !== categoryId));
    } else {
      form.setValue("categories", [...currentCategories, categoryId]);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 mb-6">
      <div className="border-b border-slate-200 px-6 py-4">
        <h2 className="font-semibold text-lg">Influencer Criteria</h2>
      </div>
      <div className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="categories"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Categories</FormLabel>
                      <div className="border border-slate-300 rounded-lg p-2 h-[120px] overflow-y-auto">
                        {isLoading ? (
                          <div className="text-sm text-slate-500">Loading categories...</div>
                        ) : (
                          <div className="grid grid-cols-2 gap-2">
                            {categories && Array.isArray(categories) ? categories.map((category: Category) => (
                              <div key={category.id} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`category-${category.id}`}
                                  checked={field.value.includes(category.id)}
                                  onCheckedChange={() => toggleCategory(category.id)}
                                />
                                <label
                                  htmlFor={`category-${category.id}`}
                                  className="text-sm font-medium"
                                >
                                  {category.name}
                                </label>
                              </div>
                            )) : (
                              <div className="text-sm text-slate-500">No categories available</div>
                            )}
                          </div>
                        )}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="minSubscribers"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Minimum Subscribers</FormLabel>
                      <Select
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select minimum subscribers" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="1000">1,000+</SelectItem>
                          <SelectItem value="5000">5,000+</SelectItem>
                          <SelectItem value="10000">10,000+</SelectItem>
                          <SelectItem value="50000">50,000+</SelectItem>
                          <SelectItem value="100000">100,000+</SelectItem>
                          <SelectItem value="500000">500,000+</SelectItem>
                          <SelectItem value="1000000">1,000,000+</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="minEngagementRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Engagement Rate</FormLabel>
                      <Select
                        onValueChange={(value) => field.onChange(parseFloat(value))}
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select minimum engagement rate" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="0">Any</SelectItem>
                          <SelectItem value="1">Above 1%</SelectItem>
                          <SelectItem value="2">Above 2%</SelectItem>
                          <SelectItem value="3">Above 3%</SelectItem>
                          <SelectItem value="5">Above 5%</SelectItem>
                          <SelectItem value="8">Above 8%</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="keywords"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Keywords/Topics</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="e.g., plant-based, eco-friendly, workout"
                        />
                      </FormControl>
                      <p className="text-xs text-slate-500 mt-1">Separate keywords with commas</p>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            <div className="hidden">
              <button type="submit" id="influencer-criteria-submit"></button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
