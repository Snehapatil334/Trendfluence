import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { useState } from "react";

const formSchema = z.object({
  minAge: z.coerce.number().min(13, "Minimum age must be at least 13"),
  maxAge: z.coerce.number().min(13, "Maximum age must be at least 13"),
  gender: z.enum(["all", "male", "female"]),
  locations: z.array(z.string()),
  interests: z.array(z.string()),
});

export type TargetAudienceFormValues = z.infer<typeof formSchema>;

interface TargetAudienceProps {
  onSubmit: (data: TargetAudienceFormValues) => void;
  defaultValues?: Partial<TargetAudienceFormValues>;
}

export default function TargetAudience({ onSubmit, defaultValues }: TargetAudienceProps) {
  const [newLocation, setNewLocation] = useState("");
  const [newInterest, setNewInterest] = useState("");

  const form = useForm<TargetAudienceFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      minAge: 20,
      maxAge: 34,
      gender: "all",
      locations: ["United States", "Canada"],
      interests: ["Fitness", "Health & Wellness", "Nutrition"],
      ...defaultValues,
    }
  });

  const handleSubmit = (data: TargetAudienceFormValues) => {
    onSubmit(data);
  };

  const addLocation = () => {
    if (newLocation && !form.getValues().locations.includes(newLocation)) {
      const currentLocations = form.getValues().locations;
      form.setValue("locations", [...currentLocations, newLocation]);
      setNewLocation("");
    }
  };

  const removeLocation = (location: string) => {
    const currentLocations = form.getValues().locations;
    form.setValue("locations", currentLocations.filter(loc => loc !== location));
  };

  const addInterest = () => {
    if (newInterest && !form.getValues().interests.includes(newInterest)) {
      const currentInterests = form.getValues().interests;
      form.setValue("interests", [...currentInterests, newInterest]);
      setNewInterest("");
    }
  };

  const removeInterest = (interest: string) => {
    const currentInterests = form.getValues().interests;
    form.setValue("interests", currentInterests.filter(int => int !== interest));
  };

  // Age options
  const ageOptions = Array.from({ length: 88 }, (_, i) => i + 13);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 mb-6">
      <div className="border-b border-slate-200 px-6 py-4">
        <h2 className="font-semibold text-lg">Target Audience</h2>
      </div>
      <div className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <FormLabel className="block text-sm font-medium mb-1.5">Age Range</FormLabel>
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="minAge"
                      render={({ field }) => (
                        <FormItem>
                          <Select
                            onValueChange={(value) => field.onChange(parseInt(value))}
                            defaultValue={field.value.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Min Age" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {ageOptions.map((age) => (
                                <SelectItem key={`min-${age}`} value={age.toString()}>
                                  {age}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="maxAge"
                      render={({ field }) => (
                        <FormItem>
                          <Select
                            onValueChange={(value) => field.onChange(parseInt(value))}
                            defaultValue={field.value.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Max Age" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {ageOptions.map((age) => (
                                <SelectItem key={`max-${age}`} value={age.toString()}>
                                  {age}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="gender"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="block text-sm font-medium mb-1.5">Gender</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex gap-4"
                        >
                          <div className="flex items-center space-x-1.5">
                            <RadioGroupItem value="male" id="male" />
                            <label htmlFor="male" className="text-sm">Male</label>
                          </div>
                          <div className="flex items-center space-x-1.5">
                            <RadioGroupItem value="female" id="female" />
                            <label htmlFor="female" className="text-sm">Female</label>
                          </div>
                          <div className="flex items-center space-x-1.5">
                            <RadioGroupItem value="all" id="all" />
                            <label htmlFor="all" className="text-sm">All Genders</label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="locations"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Locations</FormLabel>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {field.value.map((location) => (
                          <Badge key={location} variant="secondary" className="bg-primary-50 text-primary-700 hover:bg-primary-100">
                            {location}
                            <button 
                              type="button"
                              onClick={() => removeLocation(location)} 
                              className="ml-1.5 text-primary-400 hover:text-primary-600"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <Input 
                          value={newLocation}
                          onChange={(e) => setNewLocation(e.target.value)}
                          placeholder="Add a location"
                        />
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={addLocation}
                        >
                          Add
                        </Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="interests"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Interests</FormLabel>
                      <div className="flex flex-wrap gap-2 mb-2">
                        {field.value.map((interest) => (
                          <Badge key={interest} variant="secondary" className="bg-primary-50 text-primary-700 hover:bg-primary-100">
                            {interest}
                            <button 
                              type="button"
                              onClick={() => removeInterest(interest)} 
                              className="ml-1.5 text-primary-400 hover:text-primary-600"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                      <div className="flex gap-2">
                        <Input 
                          value={newInterest}
                          onChange={(e) => setNewInterest(e.target.value)}
                          placeholder="Add an interest"
                        />
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={addInterest}
                        >
                          Add
                        </Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            <div className="hidden">
              <button type="submit" id="target-audience-submit"></button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
