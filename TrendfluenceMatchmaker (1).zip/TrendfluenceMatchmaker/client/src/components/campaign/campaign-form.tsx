import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Form,
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel,
  FormMessage 
} from "@/components/ui/form";

const formSchema = z.object({
  name: z.string().min(3, "Campaign name must be at least 3 characters"),
  brand: z.string().min(2, "Brand name must be at least 2 characters"),
  campaignType: z.string(),
  startDate: z.string(),
  endDate: z.string(),
  budget: z.coerce.number().positive("Budget must be a positive number"),
  influencersNeeded: z.coerce.number().positive("Number of influencers must be positive"),
  contentTypes: z.array(z.string()),
  description: z.string().min(10, "Description must be at least 10 characters"),
});

export type CampaignFormValues = z.infer<typeof formSchema>;

interface CampaignFormProps {
  onSubmit: (data: CampaignFormValues) => void;
  defaultValues?: Partial<CampaignFormValues>;
}

export default function CampaignForm({ onSubmit, defaultValues }: CampaignFormProps) {
  const form = useForm<CampaignFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      brand: "",
      campaignType: "Product Review",
      startDate: new Date().toISOString().slice(0, 10),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
      budget: 10000,
      influencersNeeded: 5,
      contentTypes: ["YouTube Videos", "YouTube Shorts"],
      description: "",
      ...defaultValues,
    }
  });

  const handleSubmit = (data: CampaignFormValues) => {
    // Just pass the raw data - the schema will handle the conversions now
    onSubmit(data);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 mb-6">
      <div className="border-b border-slate-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-lg">Campaign Details</h2>
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <span className="font-medium">Step 1 of 3</span>
            <div className="w-16 h-1.5 bg-slate-200 rounded-full overflow-hidden">
              <div className="w-1/3 h-full bg-primary-500 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
      <div className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Campaign Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="brand"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Brand</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="campaignType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Campaign Type</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a campaign type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Product Review">Product Review</SelectItem>
                          <SelectItem value="Brand Awareness">Brand Awareness</SelectItem>
                          <SelectItem value="Sponsored Content">Sponsored Content</SelectItem>
                          <SelectItem value="Affiliate Marketing">Affiliate Marketing</SelectItem>
                          <SelectItem value="Giveaway/Contest">Giveaway/Contest</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <Label className="block text-sm font-medium mb-1.5">Start & End Date</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="budget"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Total Budget</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <span className="text-slate-500">$</span>
                          </div>
                          <Input 
                            type="number" 
                            className="pl-8" 
                            {...field}
                            onChange={(e) => {
                              const value = e.target.value === "" ? "0" : e.target.value;
                              // Explicitly convert to string to ensure proper handling
                              field.onChange(String(value));
                            }}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="influencersNeeded"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Number of Influencers Needed</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field}
                          onChange={(e) => {
                            const value = e.target.value === "" ? "0" : e.target.value;
                            // Convert to number for influencersNeeded
                            field.onChange(Number(value));
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="contentTypes"
                  render={() => (
                    <FormItem>
                      <div className="mb-2">
                        <FormLabel>Content Types</FormLabel>
                      </div>
                      <div className="flex flex-wrap gap-2.5">
                        <FormField
                          control={form.control}
                          name="contentTypes"
                          render={({ field }) => {
                            return (
                              <FormItem className="flex items-center space-x-1.5 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes('YouTube Videos')}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, 'YouTube Videos'])
                                        : field.onChange(
                                            field.value?.filter(
                                              (value) => value !== 'YouTube Videos'
                                            )
                                          )
                                    }}
                                  />
                                </FormControl>
                                <label className="text-sm">YouTube Videos</label>
                              </FormItem>
                            )
                          }}
                        />
                        <FormField
                          control={form.control}
                          name="contentTypes"
                          render={({ field }) => {
                            return (
                              <FormItem className="flex items-center space-x-1.5 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes('YouTube Shorts')}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, 'YouTube Shorts'])
                                        : field.onChange(
                                            field.value?.filter(
                                              (value) => value !== 'YouTube Shorts'
                                            )
                                          )
                                    }}
                                  />
                                </FormControl>
                                <label className="text-sm">YouTube Shorts</label>
                              </FormItem>
                            )
                          }}
                        />
                        <FormField
                          control={form.control}
                          name="contentTypes"
                          render={({ field }) => {
                            return (
                              <FormItem className="flex items-center space-x-1.5 space-y-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value?.includes('Community Posts')}
                                    onCheckedChange={(checked) => {
                                      return checked
                                        ? field.onChange([...field.value, 'Community Posts'])
                                        : field.onChange(
                                            field.value?.filter(
                                              (value) => value !== 'Community Posts'
                                            )
                                          )
                                    }}
                                  />
                                </FormControl>
                                <label className="text-sm">Community Posts</label>
                              </FormItem>
                            )
                          }}
                        />
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Product/Service Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          className="h-24 resize-none"
                          placeholder="Describe your product or service in detail..."
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            <div className="hidden">
              <button type="submit" id="campaign-form-submit"></button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
