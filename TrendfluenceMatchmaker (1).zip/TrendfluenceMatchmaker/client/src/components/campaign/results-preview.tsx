import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Filter, HelpCircle } from "lucide-react";
import InfluencerCard from "../influencer/influencer-card";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ResultsPreviewProps {
  campaignId: number;
}

export default function ResultsPreview({ campaignId }: ResultsPreviewProps) {
  const [sortBy, setSortBy] = useState("overallScore");
  const [limit, setLimit] = useState(3);

  const { data: matches, isLoading } = useQuery({
    queryKey: [`/api/campaigns/${campaignId}/matches`],
    enabled: !!campaignId,
  });

  const sortedMatches = matches ? [...matches].sort((a, b) => {
    if (sortBy === "overallScore") {
      return b.overallScore - a.overallScore;
    } else if (sortBy === "subscribers") {
      return b.influencer.subscribers - a.influencer.subscribers;
    } else if (sortBy === "engagementRate") {
      return b.influencer.engagementRate - a.influencer.engagementRate;
    } else if (sortBy === "estimatedCost") {
      return a.influencer.estimatedCost - b.influencer.estimatedCost;
    }
    return 0;
  }).slice(0, limit) : [];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 mb-6">
      <div className="border-b border-slate-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-lg">Recommended Influencers</h2>
          {!isLoading && matches && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-500">{matches.length} matches found</span>
              <Button variant="link" className="text-primary-500 text-sm font-medium hover:text-primary-600 p-0">
                View All
              </Button>
            </div>
          )}
        </div>
      </div>
      
      <div className="p-6">
        <div className="mb-4 flex flex-wrap gap-2">
          <div className="flex items-center text-sm">
            <span className="font-medium mr-2">Sort by:</span>
            <Select
              value={sortBy}
              onValueChange={setSortBy}
            >
              <SelectTrigger className="h-8 px-2 py-1 border border-slate-300 rounded-lg text-sm w-36">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="overallScore">Match Score</SelectItem>
                <SelectItem value="subscribers">Subscribers</SelectItem>
                <SelectItem value="engagementRate">Engagement Rate</SelectItem>
                <SelectItem value="estimatedCost">Est. Cost</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center ml-auto">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="sm" className="text-sm gap-1">
                    <Filter className="h-4 w-4" />
                    <span>Filters</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Filter options coming soon</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {[1, 2, 3].map(i => (
              <div key={i} className="border border-slate-200 rounded-xl overflow-hidden">
                <Skeleton className="w-full h-28" />
                <div className="p-4">
                  <div className="flex">
                    <Skeleton className="w-12 h-12 rounded-full -mt-8 mr-3" />
                    <div className="w-full">
                      <Skeleton className="h-4 w-1/2 mb-1" />
                      <Skeleton className="h-3 w-1/3" />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mt-3 text-center">
                    <Skeleton className="h-8" />
                    <Skeleton className="h-8" />
                    <Skeleton className="h-8" />
                  </div>
                  <div className="mt-3">
                    <div className="flex flex-wrap gap-1.5">
                      <Skeleton className="h-4 w-16 rounded-full" />
                      <Skeleton className="h-4 w-20 rounded-full" />
                      <Skeleton className="h-4 w-14 rounded-full" />
                    </div>
                  </div>
                  <div className="mt-4 flex justify-between items-center">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : matches?.length ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {sortedMatches.map((match) => (
              <InfluencerCard 
                key={match.influencerId} 
                influencer={match.influencer} 
                matchScore={match.overallScore}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="flex justify-center mb-3">
              <HelpCircle className="h-12 w-12 text-slate-300" />
            </div>
            <h3 className="text-lg font-medium text-slate-800">No matches found</h3>
            <p className="text-sm text-slate-500 mt-1">Try adjusting your criteria to find more influencers</p>
          </div>
        )}

        {!isLoading && matches?.length > limit && (
          <div className="mt-6 flex justify-center">
            <Button 
              variant="outline" 
              className="border-primary-500 text-primary-500 hover:bg-primary-50"
              onClick={() => setLimit(prev => prev + 3)}
            >
              Load More Influencers
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
