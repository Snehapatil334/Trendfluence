import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from "recharts";
import { Campaign, InfluencerMatch } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface EnhancedInfluencerMatch extends InfluencerMatch {
  influencer: {
    id: number;
    displayName: string;
    subscribers: number;
    avgViews: number;
    estimatedCost: number;
    engagementRate: string | number;
    tags: string[];
  };
}

export default function RecommendationAccuracy() {
  const [selectedCampaign, setSelectedCampaign] = useState<string>("");
  
  // Fetch campaigns
  const { data: campaigns, isLoading: campaignsLoading } = useQuery<Campaign[]>({
    queryKey: ['/api/campaigns'],
  });
  
  // Fetch matches for selected campaign
  const { data: matches, isLoading: matchesLoading } = useQuery<EnhancedInfluencerMatch[]>({
    queryKey: ['/api/campaigns', selectedCampaign, 'matches'],
    enabled: !!selectedCampaign, // Only run query if a campaign is selected
  });
  
  // Calculate match metrics
  const matchMetrics = matches && matches.length > 0 ? {
    // Average scores
    avgPerformanceScore: matches.reduce((sum, match) => sum + parseFloat(String(match.performanceScore)), 0) / matches.length,
    avgAudienceScore: matches.reduce((sum, match) => sum + parseFloat(String(match.audienceScore)), 0) / matches.length,
    avgContentScore: matches.reduce((sum, match) => sum + parseFloat(String(match.contentScore)), 0) / matches.length,
    avgBudgetScore: matches.reduce((sum, match) => sum + parseFloat(String(match.budgetScore)), 0) / matches.length,
    avgOverallScore: matches.reduce((sum, match) => sum + parseFloat(String(match.overallScore)), 0) / matches.length,
    
    // Distribution of scores
    highMatches: matches.filter(match => parseFloat(String(match.overallScore)) > 8).length,
    mediumMatches: matches.filter(match => parseFloat(String(match.overallScore)) > 6 && parseFloat(String(match.overallScore)) <= 8).length,
    lowMatches: matches.filter(match => parseFloat(String(match.overallScore)) <= 6).length,
    
    // Quality metrics
    relevanceRate: Math.min(100, matches.filter(match => parseFloat(String(match.contentScore)) > 7).length / matches.length * 100),
    budgetEfficiency: Math.min(100, matches.filter(match => parseFloat(String(match.budgetScore)) > 7).length / matches.length * 100),
    audienceAlignmentRate: Math.min(100, matches.filter(match => parseFloat(String(match.audienceScore)) > 7).length / matches.length * 100),
  } : null;

  // Prepare data for radar chart
  const radarData = matchMetrics ? [
    {
      subject: 'Performance',
      score: matchMetrics.avgPerformanceScore,
      fullMark: 10,
    },
    {
      subject: 'Audience Match',
      score: matchMetrics.avgAudienceScore,
      fullMark: 10,
    },
    {
      subject: 'Content Relevance',
      score: matchMetrics.avgContentScore,
      fullMark: 10,
    },
    {
      subject: 'Budget Efficiency',
      score: matchMetrics.avgBudgetScore,
      fullMark: 10,
    },
  ] : [];

  // Prepare data for bar chart
  const barData = matchMetrics ? [
    {
      name: 'High Match (>8)',
      value: matchMetrics.highMatches,
    },
    {
      name: 'Medium Match (6-8)',
      value: matchMetrics.mediumMatches,
    },
    {
      name: 'Low Match (<6)',
      value: matchMetrics.lowMatches,
    },
  ] : [];

  // Format percentage
  const formatPercent = (value: number) => `${value.toFixed(1)}%`;

  const isLoading = campaignsLoading || (selectedCampaign && matchesLoading);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">Recommendation Accuracy</h2>
          <p className="text-slate-500">Evaluate how well influencer recommendations match campaign requirements</p>
        </div>
        <div className="w-full md:w-64">
          <Select 
            value={selectedCampaign} 
            onValueChange={setSelectedCampaign}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select campaign" />
            </SelectTrigger>
            <SelectContent>
              {campaigns?.map((campaign) => (
                <SelectItem key={campaign.id} value={campaign.id.toString()}>
                  {campaign.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      ) : !selectedCampaign ? (
        <Card>
          <CardContent className="py-10 text-center">
            <p className="text-slate-500">Please select a campaign to view recommendation accuracy metrics</p>
          </CardContent>
        </Card>
      ) : !matches || matches.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center">
            <p className="text-slate-500">No influencer matches found for this campaign</p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <p className="text-sm font-medium text-slate-500">Average Match Score</p>
                  <h3 className="text-3xl font-bold mt-1">{matchMetrics?.avgOverallScore.toFixed(1)}/10</h3>
                  <Badge className={`mt-2 ${matchMetrics && matchMetrics.avgOverallScore > 7 ? "bg-green-100 text-green-700" : ""}`}>
                    {matchMetrics && matchMetrics.avgOverallScore > 7 ? "Good" : "Needs Improvement"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <p className="text-sm font-medium text-slate-500">Content Relevance</p>
                  <h3 className="text-3xl font-bold mt-1">{formatPercent(matchMetrics?.relevanceRate || 0)}</h3>
                  <Badge className={`mt-2 ${matchMetrics && matchMetrics.relevanceRate > 70 ? "bg-green-100 text-green-700" : ""}`}>
                    {matchMetrics && matchMetrics.relevanceRate > 70 ? "Good" : "Needs Improvement"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <p className="text-sm font-medium text-slate-500">Audience Alignment</p>
                  <h3 className="text-3xl font-bold mt-1">{formatPercent(matchMetrics?.audienceAlignmentRate || 0)}</h3>
                  <Badge className={`mt-2 ${matchMetrics && matchMetrics.audienceAlignmentRate > 70 ? "bg-green-100 text-green-700" : ""}`}>
                    {matchMetrics && matchMetrics.audienceAlignmentRate > 70 ? "Good" : "Needs Improvement"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <p className="text-sm font-medium text-slate-500">Budget Efficiency</p>
                  <h3 className="text-3xl font-bold mt-1">{formatPercent(matchMetrics?.budgetEfficiency || 0)}</h3>
                  <Badge className={`mt-2 ${matchMetrics && matchMetrics.budgetEfficiency > 70 ? "bg-green-100 text-green-700" : ""}`}>
                    {matchMetrics && matchMetrics.budgetEfficiency > 70 ? "Good" : "Needs Improvement"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Score Distribution</CardTitle>
                <CardDescription>Distribution of overall match scores</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={barData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [value, 'Count']} />
                      <Legend />
                      <Bar dataKey="value" name="Number of Influencers" fill="#3B82F6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Score Breakdown</CardTitle>
                <CardDescription>Average scores across different metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="subject" />
                      <PolarRadiusAxis angle={30} domain={[0, 10]} />
                      <Radar
                        name="Average Score"
                        dataKey="score"
                        stroke="#3B82F6"
                        fill="#3B82F6"
                        fillOpacity={0.6}
                      />
                      <Tooltip formatter={(value) => {
                          if (typeof value === 'number') {
                            return [`${value.toFixed(1)}/10`, 'Score'];
                          }
                          return [value, 'Score'];
                        }} />
                      <Legend />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}