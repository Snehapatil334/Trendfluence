import { Link, useLocation } from "wouter";
import { useMobile } from "@/hooks/use-mobile";
import { useState } from "react";
import { 
  Home, 
  Megaphone, 
  Users, 
  BarChart3, 
  BarChart4, 
  LineChart, 
  PieChart,
  ChevronDown,
  ChevronRight 
} from "lucide-react";

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  href: string;
  active?: boolean;
}

function NavItem({ icon, label, href, active }: NavItemProps) {
  return (
    <li>
      <Link href={href} className={`flex items-center gap-3 ${active ? 'text-primary-500 bg-primary-50' : 'text-slate-500'} px-2 lg:px-3 py-2 rounded-lg hover:bg-slate-100`}>
        <div className="w-5 text-center">{icon}</div>
        <span className="hidden lg:inline">{label}</span>
      </Link>
    </li>
  );
}

interface SubNavItemProps {
  icon: React.ReactNode;
  label: string;
  href: string;
  active?: boolean;
}

function SubNavItem({ icon, label, href, active }: SubNavItemProps) {
  return (
    <li>
      <Link href={href} className={`flex items-center gap-3 ${active ? 'text-primary-500' : 'text-slate-500'} px-2 lg:px-3 py-1.5 rounded-lg hover:bg-slate-50 ml-6 lg:ml-8 text-sm`}>
        <div className="w-4 text-center">{icon}</div>
        <span className="hidden lg:inline">{label}</span>
      </Link>
    </li>
  );
}

interface CollapsibleNavItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  items: {
    icon: React.ReactNode;
    label: string;
    href: string;
  }[];
  href: string;
}

function CollapsibleNavItem({ icon, label, items, href, active }: CollapsibleNavItemProps) {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(active || location.startsWith(href));
  const isActive = active || location.startsWith(href);
  
  return (
    <li className="space-y-1">
      <div className="flex items-center">
        <Link href={href} className={`flex-1 flex items-center gap-3 ${isActive ? 'text-primary-500 bg-primary-50' : 'text-slate-500'} px-2 lg:px-3 py-2 rounded-lg hover:bg-slate-100`}>
          <div className="w-5 text-center">{icon}</div>
          <span className="hidden lg:inline">{label}</span>
        </Link>
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="mr-2 p-1 rounded-md hover:bg-slate-100"
        >
          {isOpen ? 
            <ChevronDown size={16} className={isActive ? 'text-primary-500' : 'text-slate-400'} /> : 
            <ChevronRight size={16} className={isActive ? 'text-primary-500' : 'text-slate-400'} />
          }
        </button>
      </div>
      
      {isOpen && (
        <ul className="mt-1 space-y-1">
          {items.map((item, index) => (
            <SubNavItem
              key={index}
              icon={item.icon}
              label={item.label}
              href={item.href}
              active={location === item.href}
            />
          ))}
        </ul>
      )}
    </li>
  );
}

export default function Sidebar() {
  const [location] = useLocation();
  const isMobile = useMobile();

  return (
    <aside className={`h-full w-16 lg:w-56 fixed bg-white border-r border-slate-200 dashboard-height transition-all duration-300 ease-in-out`}>
      <div className="overflow-y-auto h-full py-4">
        <ul className="space-y-1 px-2">
          <NavItem 
            icon={<Home size={18} />} 
            label="Dashboard" 
            href="/" 
            active={location === "/"} 
          />
          <NavItem 
            icon={<Megaphone size={18} />} 
            label="Campaigns" 
            href="/campaigns" 
            active={location.startsWith("/campaigns")} 
          />
          <NavItem 
            icon={<Users size={18} />} 
            label="Influencers" 
            href="/influencers" 
            active={location.startsWith("/influencers")} 
          />
          <CollapsibleNavItem 
            icon={<BarChart3 size={18} />}
            label="Analytics" 
            href="/analytics"
            active={location.startsWith("/analytics")}
            items={[
              {
                icon: <BarChart4 size={16} />,
                label: "Overview",
                href: "/analytics"
              },
              {
                icon: <LineChart size={16} />,
                label: "Campaign Performance",
                href: "/analytics/campaigns"
              },
              {
                icon: <PieChart size={16} />,
                label: "Audience Insights",
                href: "/analytics/audience"
              }
            ]}
          />

        </ul>
      </div>
    </aside>
  );
}
