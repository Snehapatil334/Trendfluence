import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, Bell, LogOut, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export default function Header() {
  const [searchOpen, setSearchOpen] = useState(false);
  const { user, logoutMutation } = useAuth();
  const [_, navigate] = useLocation();

  // Generate user initials for avatar
  const getUserInitials = () => {
    if (!user) return "?";
    
    // Try to use company name
    if (user.companyName) {
      const words = user.companyName.split(' ');
      if (words.length > 1) {
        return (words[0][0] + words[1][0]).toUpperCase();
      }
      return user.companyName.substring(0, 2).toUpperCase();
    }
    
    // Fallback to username
    return user.username.substring(0, 2).toUpperCase();
  };

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        navigate("/auth");
      }
    });
  };

  return (
    <header className="bg-white border-b border-slate-200 h-16 fixed top-0 left-0 right-0 z-10">
      <div className="flex items-center justify-between h-full px-4 lg:px-6">
        <div className="flex items-center">
          <Link href="/">
            <div className="flex items-center gap-2 font-semibold text-xl cursor-pointer">
              <span className="text-primary">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-trend-up">
                  <path d="M3 3v18h18" />
                  <path d="m19 9-5 5-4-4-3 3" />
                  <path d="M14 9h5v5" />
                </svg>
              </span>
              <span>Trendfluence</span>
            </div>
          </Link>
        </div>
        <div className="flex items-center gap-4">
          <div className={`${searchOpen ? 'flex' : 'hidden'} md:flex items-center relative`}>
            <Input
              type="text"
              placeholder="Search..."
              className="w-full md:w-auto bg-slate-100 border-0 focus-visible:ring-1 text-sm"
            />
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute right-0 hover:bg-transparent"
            >
              <Search className="h-4 w-4 text-slate-500" />
            </Button>
          </div>
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setSearchOpen(!searchOpen)}>
            <Search className="h-5 w-5 text-slate-500" />
          </Button>
          <Button variant="ghost" size="icon" className="bg-slate-100 rounded-full">
            <Bell className="h-5 w-5 text-slate-500" />
          </Button>
          
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="p-0 h-auto flex items-center gap-2 hover:bg-transparent">
                  <Avatar className="h-8 w-8 bg-primary/10 border border-primary/20">
                    <AvatarFallback className="text-primary text-sm font-medium">
                      {getUserInitials()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden md:block text-sm font-medium">
                    {user.companyName}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium">{user.companyName}</p>
                    <p className="text-xs text-muted-foreground">{user.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/profile" className="cursor-pointer">Profile Settings</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  className="text-destructive focus:text-destructive cursor-pointer"
                  onClick={handleLogout}
                  disabled={logoutMutation.isPending}
                >
                  {logoutMutation.isPending ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <LogOut className="mr-2 h-4 w-4" />
                  )}
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button variant="default" size="sm" asChild>
              <Link href="/auth">Login</Link>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
