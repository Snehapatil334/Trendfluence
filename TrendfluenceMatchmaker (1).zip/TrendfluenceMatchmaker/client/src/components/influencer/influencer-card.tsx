import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Influencer } from "@shared/schema";

interface InfluencerCardProps {
  influencer: Influencer;
  matchScore?: number;
}

export default function InfluencerCard({ influencer, matchScore }: InfluencerCardProps) {
  // Format numbers with K/M suffix
  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(0)}K`;
    }
    return num.toString();
  };
  
  // Format currency
  const formatCost = (value: any) => {
    if (value === null || value === undefined) return 'N/A';
    
    try {
      const numValue = Number(value);
      if (isNaN(numValue)) return 'N/A';
      return numValue.toFixed(0);
    } catch (error) {
      return 'N/A';
    }
  };

  // Determine match score color
  const getScoreColor = (score: number) => {
    if (score >= 90) return 'bg-secondary-500';
    if (score >= 80) return 'bg-accent-500';
    return 'bg-slate-500';
  };

  return (
    <div className="border border-slate-200 rounded-xl overflow-hidden group hover:shadow-md transition-shadow">
      <div className="relative">
        <img 
          src={influencer.bannerImageUrl || "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=500&q=80"} 
          alt={`${influencer.channelTitle} channel banner`}
          className="w-full h-28 object-cover"
        />
        {matchScore && (
          <div className="absolute top-3 right-3 bg-white rounded-full py-0.5 px-2 text-xs font-medium flex items-center">
            <span className={`w-1.5 h-1.5 rounded-full ${getScoreColor(matchScore)} mr-1`}></span>
            <span>{Math.round(matchScore)}% Match</span>
          </div>
        )}
      </div>
      <div className="p-4">
        <div className="flex">
          <img 
            src={influencer.profileImageUrl || "https://images.unsplash.com/photo-1511367461989-f85a21fda167?auto=format&fit=crop&w=100&q=80"} 
            alt={influencer.displayName}
            className="w-12 h-12 rounded-full border-2 border-white -mt-8 mr-3 object-cover"
          />
          <div>
            <h3 className="font-semibold text-slate-800">{influencer.channelTitle}</h3>
            <p className="text-sm text-slate-500">{influencer.displayName}</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2 mt-3 text-center">
          <div>
            <p className="text-xs text-slate-500">Subscribers</p>
            <p className="font-medium">{formatNumber(influencer.subscribers)}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Avg. Views</p>
            <p className="font-medium">{formatNumber(influencer.avgViews)}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Engagement</p>
            <p className="font-medium">{influencer.engagementRate}%</p>
          </div>
        </div>
        <div className="mt-3">
          <div className="flex flex-wrap gap-1.5">
            {(influencer.tags as string[]).slice(0, 3).map((tag, index) => (
              <span key={index} className="bg-slate-100 px-2 py-0.5 rounded-full text-xs text-slate-700">
                {tag}
              </span>
            ))}
          </div>
        </div>
        <div className="mt-4 flex justify-between items-center">
          <span className="text-sm font-medium">
            Est. Cost: <span className="text-slate-700">
              {formatCost(influencer.estimatedCost) === 'N/A' 
                ? 'N/A' 
                : `$${formatCost(influencer.estimatedCost)}`}
            </span>
          </span>
          <Link href={`/influencers/${influencer.id}`}>
            <Button variant="link" className="text-sm p-0 h-auto">View Profile</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
