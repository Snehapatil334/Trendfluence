import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  BarChart,
  ResponsiveContainer,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  LineChart,
  Line
} from "recharts";
import { Campaign } from "@shared/schema";
import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function CampaignAnalytics() {
  const [timeRange, setTimeRange] = useState("last30days");
  
  const { data: campaigns, isLoading } = useQuery<Campaign[]>({
    queryKey: ["/api/campaigns"],
  });

  // Mock data for campaign performance over time
  const performanceData = [
    { month: 'Jan', impressions: 4000, engagement: 2400, conversion: 1200 },
    { month: 'Feb', impressions: 3000, engagement: 1398, conversion: 900 },
    { month: 'Mar', impressions: 2000, engagement: 9800, conversion: 1500 },
    { month: 'Apr', impressions: 2780, engagement: 3908, conversion: 2100 },
    { month: 'May', impressions: 1890, engagement: 4800, conversion: 2400 },
    { month: 'Jun', impressions: 2390, engagement: 3800, conversion: 3000 },
    { month: 'Jul', impressions: 3490, engagement: 4300, conversion: 3500 },
  ];

  // Mock ROI data
  const roiData = [
    { name: 'Beauty', roi: 245 },
    { name: 'Fashion', roi: 187 },
    { name: 'Gaming', roi: 320 },
    { name: 'Fitness', roi: 256 },
    { name: 'Tech', roi: 198 },
  ];

  // Since engagementRate isn't part of the Campaign type directly, we use a mock value for demonstration
  // In a real application, this would come from an API endpoint that provides campaign performance data
  const campaignEngagementRates: Record<number, number> = {
    1: 4.2,
    2: 5.7,
    3: 3.8,
    4: 6.3,
    5: 2.9,
    6: 7.1
  };
  
  // Find the top performing campaign by average engagement
  const topCampaign = campaigns?.reduce((prev, current) => {
    const prevEngagement = campaignEngagementRates[prev.id] || 0;
    const currentEngagement = campaignEngagementRates[current.id] || 0;
    return currentEngagement > prevEngagement ? current : prev;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Campaign Performance</h1>
        <div className="flex items-center space-x-4">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="last7days">Last 7 Days</SelectItem>
              <SelectItem value="last30days">Last 30 Days</SelectItem>
              <SelectItem value="last90days">Last 90 Days</SelectItem>
              <SelectItem value="lastyear">Last Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {isLoading ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {Array(3).fill(0).map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-36" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-16 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Campaigns</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{campaigns?.length || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                +{Math.floor(Math.random() * 10)}% from last month
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Average Engagement Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {campaigns && campaigns.length > 0
                  ? (campaigns.reduce((sum, campaign) => 
                      sum + (campaignEngagementRates[campaign.id] || 0), 
                      0) / campaigns.length).toFixed(2)
                  : "0.00"}%
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {Math.random() > 0.5 ? "+" : "-"}{Math.floor(Math.random() * 5)}% from last month
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Top Performing Campaign</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold truncate">{topCampaign?.name || "N/A"}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {topCampaign ? `${campaignEngagementRates[topCampaign.id]?.toFixed(2) || '0.00'}% engagement rate` : "No data available"}
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Performance Metrics Over Time</CardTitle>
            <CardDescription>Showing impressions, engagement, and conversion rates</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={performanceData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="impressions" stroke="#8884d8" activeDot={{ r: 8 }} />
                <Line type="monotone" dataKey="engagement" stroke="#82ca9d" />
                <Line type="monotone" dataKey="conversion" stroke="#ffc658" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Campaign ROI by Category</CardTitle>
            <CardDescription>Return on investment percentage</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={roiData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="roi" fill="#8884d8" name="ROI %" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}