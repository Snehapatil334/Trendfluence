import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  CheckIcon, 
  Search, 
  SlidersHorizontal, 
  PlusCircle, 
  Youtube, 
  Import, 
  Loader2 
} from "lucide-react";
import InfluencerCard from "@/components/influencer/influencer-card";
import { Influencer } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Influencers() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterOpen, setFilterOpen] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [subscriberFilter, setSubscriberFilter] = useState<number>(1000);
  const [engagementFilter, setEngagementFilter] = useState<number>(0);

  // Fetch influencers and categories
  const { data: influencers, isLoading } = useQuery({
    queryKey: ['/api/influencers'],
  });

  const { data: categories } = useQuery({
    queryKey: ['/api/categories'],
  });

  // Filter influencers based on search and filters
  const filteredInfluencers = influencers?.filter((influencer: Influencer) => {
    // Search filter
    const matchesSearch = searchQuery === "" || 
      influencer.channelTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      influencer.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (influencer.description && influencer.description.toLowerCase().includes(searchQuery.toLowerCase()));
    
    // Category filter
    const matchesCategory = categoryFilter === "all" || 
      (influencer.categories as number[]).includes(parseInt(categoryFilter));
    
    // Subscriber filter
    const matchesSubscribers = influencer.subscribers >= subscriberFilter;
    
    // Engagement filter
    const matchesEngagement = parseFloat(influencer.engagementRate.toString()) >= engagementFilter;
    
    return matchesSearch && matchesCategory && matchesSubscribers && matchesEngagement;
  });

  // Format subscriber counts for display
  const formatSubscriberCount = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M+`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(0)}K+`;
    }
    return `${count}+`;
  };

  // YouTube search state
  const [youtubeDialogOpen, setYoutubeDialogOpen] = useState(false);
  const [youtubeSearchQuery, setYoutubeSearchQuery] = useState("");
  const [youtubeResults, setYoutubeResults] = useState<any[]>([]);
  const [selectedChannels, setSelectedChannels] = useState<Set<string>>(new Set());
  const [selectedCategories, setSelectedCategories] = useState<number[]>([]);
  const { toast } = useToast();

  // YouTube search query
  const { mutate: searchYoutube, isPending: isSearching } = useMutation({
    mutationFn: async (query: string) => {
      const response = await apiRequest("GET", `/api/youtube/search?q=${encodeURIComponent(query)}`);
      return response.json();
    },
    onSuccess: (data) => {
      setYoutubeResults(data);
    },
    onError: (error: Error) => {
      toast({
        title: "Search failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Import selected YouTube channels
  const { mutate: importChannels, isPending: isImporting } = useMutation({
    mutationFn: async () => {
      // Convert set to array
      const channelIds = Array.from(selectedChannels);
      
      // Create an array of promises for each channel import
      const importPromises = channelIds.map(channelId => 
        apiRequest("POST", "/api/youtube/fetch-and-store", {
          channelId,
          categoryIds: selectedCategories
        }).then(res => res.json())
      );
      
      // Wait for all imports to complete
      return Promise.all(importPromises);
    },
    onSuccess: (data) => {
      // Update the influencers list
      queryClient.invalidateQueries({ queryKey: ['/api/influencers'] });
      
      // Close dialog and reset state
      setYoutubeDialogOpen(false);
      setYoutubeResults([]);
      setSelectedChannels(new Set());
      setSelectedCategories([]);
      
      toast({
        title: "Import successful",
        description: `Imported ${data.length} YouTube channels to your influencer database.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Import failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle YouTube search
  const handleYoutubeSearch = () => {
    if (!youtubeSearchQuery.trim()) return;
    searchYoutube(youtubeSearchQuery);
  };

  // Toggle channel selection
  const toggleChannelSelection = (channelId: string) => {
    const newSelection = new Set(selectedChannels);
    if (newSelection.has(channelId)) {
      newSelection.delete(channelId);
    } else {
      newSelection.add(channelId);
    }
    setSelectedChannels(newSelection);
  };

  // Handle category selection
  const handleCategoryChange = (categoryId: string) => {
    const id = parseInt(categoryId);
    if (selectedCategories.includes(id)) {
      setSelectedCategories(selectedCategories.filter(c => c !== id));
    } else {
      setSelectedCategories([...selectedCategories, id]);
    }
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Influencer Database</h1>
          <p className="text-slate-500 text-sm mt-1">Browse and discover YouTube influencers for your campaigns</p>
        </div>
        <Dialog open={youtubeDialogOpen} onOpenChange={setYoutubeDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Youtube className="h-4 w-4" />
              <span>Import from YouTube</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[625px]">
            <DialogHeader>
              <DialogTitle>Import Influencers from YouTube</DialogTitle>
              <DialogDescription>
                Search for YouTube channels and import them to your influencer database.
              </DialogDescription>
            </DialogHeader>
            
            <div className="mt-4 space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Search YouTube channels..."
                  value={youtubeSearchQuery}
                  onChange={(e) => setYoutubeSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleYoutubeSearch()}
                  className="flex-1"
                />
                <Button 
                  onClick={handleYoutubeSearch} 
                  disabled={isSearching || !youtubeSearchQuery.trim()}
                >
                  {isSearching ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Search className="h-4 w-4 mr-2" />
                  )}
                  Search
                </Button>
              </div>
              
              {youtubeResults.length > 0 && (
                <>
                  <div className="border rounded-md h-64 overflow-y-auto p-2">
                    {youtubeResults.map((channel) => (
                      <div 
                        key={channel.id.channelId} 
                        className={`flex items-center p-2 mb-1 rounded-md hover:bg-slate-50 cursor-pointer ${
                          selectedChannels.has(channel.id.channelId) ? 'bg-slate-50 border border-slate-200' : ''
                        }`}
                        onClick={() => toggleChannelSelection(channel.id.channelId)}
                      >
                        <div className="flex-shrink-0 mr-3">
                          <img 
                            src={channel.snippet.thumbnails.default.url} 
                            alt={channel.snippet.title}
                            className="w-10 h-10 rounded-full"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{channel.snippet.title}</p>
                          <p className="text-xs text-slate-500 truncate">{channel.snippet.description}</p>
                        </div>
                        <div className="flex-shrink-0 ml-2">
                          {selectedChannels.has(channel.id.channelId) && (
                            <CheckIcon className="h-5 w-5 text-green-500" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="space-y-2">
                    <label className="block text-sm font-medium">Assign Categories (Optional)</label>
                    <div className="flex flex-wrap gap-2">
                      {categories?.map((category) => (
                        <Badge 
                          key={category.id}
                          variant={selectedCategories.includes(category.id) ? "default" : "outline"}
                          className="cursor-pointer"
                          onClick={() => handleCategoryChange(category.id.toString())}
                        >
                          {category.name}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setYoutubeDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={() => importChannels()}
                disabled={isImporting || selectedChannels.size === 0}
              >
                {isImporting ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Import className="h-4 w-4 mr-2" />
                )}
                Import Selected ({selectedChannels.size})
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 mb-6">
        <div className="p-4 border-b border-slate-200">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
              <Input 
                type="search" 
                placeholder="Search influencers by name, channel, or keywords..." 
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="text-sm gap-1"
              onClick={() => setFilterOpen(!filterOpen)}
            >
              <SlidersHorizontal className="h-4 w-4" />
              <span>Filters</span>
            </Button>
          </div>

          {filterOpen && (
            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-200">
              <div>
                <label className="block text-sm font-medium mb-1.5">Category</label>
                <Select 
                  value={categoryFilter} 
                  onValueChange={setCategoryFilter}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories?.map((category) => (
                      <SelectItem key={category.id} value={category.id.toString()}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1.5">Minimum Subscribers</label>
                <Select 
                  value={subscriberFilter.toString()} 
                  onValueChange={(value) => setSubscriberFilter(parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select minimum subscribers" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1000">1,000+</SelectItem>
                    <SelectItem value="5000">5,000+</SelectItem>
                    <SelectItem value="10000">10,000+</SelectItem>
                    <SelectItem value="50000">50,000+</SelectItem>
                    <SelectItem value="100000">100,000+</SelectItem>
                    <SelectItem value="500000">500,000+</SelectItem>
                    <SelectItem value="1000000">1,000,000+</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1.5">
                  Minimum Engagement Rate: {engagementFilter}%
                </label>
                <Slider
                  value={[engagementFilter]}
                  min={0}
                  max={10}
                  step={0.5}
                  onValueChange={(value) => setEngagementFilter(value[0])}
                />
              </div>
            </div>
          )}
        </div>

        <div className="p-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="border border-slate-200 rounded-xl overflow-hidden">
                  <Skeleton className="w-full h-28" />
                  <div className="p-4">
                    <div className="flex">
                      <Skeleton className="w-12 h-12 rounded-full -mt-8 mr-3" />
                      <div className="w-full">
                        <Skeleton className="h-4 w-1/2 mb-1" />
                        <Skeleton className="h-3 w-1/3" />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 mt-3 text-center">
                      <Skeleton className="h-8" />
                      <Skeleton className="h-8" />
                      <Skeleton className="h-8" />
                    </div>
                    <div className="mt-3">
                      <div className="flex flex-wrap gap-1.5">
                        <Skeleton className="h-4 w-16 rounded-full" />
                        <Skeleton className="h-4 w-20 rounded-full" />
                        <Skeleton className="h-4 w-14 rounded-full" />
                      </div>
                    </div>
                    <div className="mt-4 flex justify-between items-center">
                      <Skeleton className="h-4 w-20" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredInfluencers?.length > 0 ? (
            <>
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm text-slate-500">
                  Showing <strong>{filteredInfluencers.length}</strong> influencers
                  {(searchQuery || categoryFilter !== "all" || subscriberFilter > 1000 || engagementFilter > 0) && (
                    <span> with applied filters</span>
                  )}
                </p>
                
                {(searchQuery || categoryFilter !== "all" || subscriberFilter > 1000 || engagementFilter > 0) && (
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => {
                      setSearchQuery("");
                      setCategoryFilter("all");
                      setSubscriberFilter(1000);
                      setEngagementFilter(0);
                    }}
                  >
                    Clear filters
                  </Button>
                )}
              </div>
            
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredInfluencers.map((influencer: Influencer) => (
                  <InfluencerCard 
                    key={influencer.id} 
                    influencer={influencer} 
                  />
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <div className="mx-auto w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mb-3">
                <Search className="h-6 w-6 text-slate-400" />
              </div>
              <h3 className="text-lg font-medium text-slate-900 mb-1">No influencers found</h3>
              <p className="text-slate-500 mb-4">
                Try adjusting your search or filters to find influencers.
              </p>
              <Button 
                variant="outline"
                onClick={() => {
                  setSearchQuery("");
                  setCategoryFilter("all");
                  setSubscriberFilter(1000);
                  setEngagementFilter(0);
                }}
              >
                Clear all filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
