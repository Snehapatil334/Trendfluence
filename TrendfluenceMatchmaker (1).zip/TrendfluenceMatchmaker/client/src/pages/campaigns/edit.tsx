import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import CampaignForm, { CampaignFormValues } from "@/components/campaign/campaign-form";
import TargetAudience, { TargetAudienceFormValues } from "@/components/campaign/target-audience";
import InfluencerCriteria, { InfluencerCriteriaFormValues } from "@/components/campaign/influencer-criteria";
import { Campaign, TargetAudience as TargetAudienceType, InfluencerCriteria as InfluencerCriteriaType } from "@shared/schema";

export default function EditCampaign() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [match, params] = useRoute<{ id: string }>("/campaigns/edit/:id");
  const [currentStep, setCurrentStep] = useState(1);
  const [campaignData, setCampaignData] = useState<CampaignFormValues | null>(null);
  const [audienceData, setAudienceData] = useState<TargetAudienceFormValues | null>(null);
  const [criteriaData, setCriteriaData] = useState<InfluencerCriteriaFormValues | null>(null);

  // Fetch campaign data
  const { data: campaign, isLoading: isCampaignLoading } = useQuery<Campaign>({
    queryKey: [`/api/campaigns/${params?.id}`],
    enabled: !!params?.id,
  });
  
  // Fetch target audience
  const { data: targetAudience, isLoading: isTargetAudienceLoading } = useQuery<TargetAudienceType>({
    queryKey: [`/api/campaigns/${params?.id}/target-audience`],
    enabled: !!params?.id,
  });
  
  // Fetch influencer criteria
  const { data: influencerCriteria, isLoading: isInfluencerCriteriaLoading } = useQuery<InfluencerCriteriaType>({
    queryKey: [`/api/campaigns/${params?.id}/influencer-criteria`],
    enabled: !!params?.id,
  });

  // Set initial form data from fetched data with proper type conversion
  useEffect(() => {
    if (campaign && !campaignData) {
      // Convert server data to form format
      const formattedData: CampaignFormValues = {
        name: campaign.name,
        brand: campaign.brand,
        campaignType: campaign.campaignType,
        startDate: typeof campaign.startDate === 'string' ? campaign.startDate : new Date(campaign.startDate).toISOString().split('T')[0],
        endDate: typeof campaign.endDate === 'string' ? campaign.endDate : new Date(campaign.endDate).toISOString().split('T')[0],
        budget: Number(campaign.budget),
        influencersNeeded: campaign.influencersNeeded,
        contentTypes: Array.isArray(campaign.contentTypes) ? campaign.contentTypes : [],
        description: campaign.description || ''
      };
      setCampaignData(formattedData);
    }
  }, [campaign, campaignData]);

  useEffect(() => {
    if (targetAudience && !audienceData) {
      // Convert server data to form format with type safety
      const formattedData: TargetAudienceFormValues = {
        minAge: targetAudience.minAge,
        maxAge: targetAudience.maxAge,
        gender: (targetAudience.gender === 'male' || targetAudience.gender === 'female' || targetAudience.gender === 'all') 
          ? (targetAudience.gender as "male" | "female" | "all")
          : "all",
        locations: Array.isArray(targetAudience.locations) ? targetAudience.locations : [],
        interests: Array.isArray(targetAudience.interests) ? targetAudience.interests : []
      };
      setAudienceData(formattedData);
    }
  }, [targetAudience, audienceData]);

  useEffect(() => {
    if (influencerCriteria && !criteriaData) {
      // Convert server data to form format
      const formattedData: InfluencerCriteriaFormValues = {
        categories: Array.isArray(influencerCriteria.categories) ? influencerCriteria.categories : [],
        minSubscribers: influencerCriteria.minSubscribers,
        minEngagementRate: typeof influencerCriteria.minEngagementRate === 'string' ? Number(influencerCriteria.minEngagementRate) : influencerCriteria.minEngagementRate,
        keywords: Array.isArray(influencerCriteria.keywords) ? influencerCriteria.keywords.join(', ') : ''
      };
      setCriteriaData(formattedData);
    }
  }, [influencerCriteria, criteriaData]);

  // Update campaign mutation
  const updateCampaign = useMutation({
    mutationFn: async (data: CampaignFormValues) => {
      // Format the data properly for the API
      const formattedData = {
        ...data,
        // Convert string dates to Date objects to match the expected format from schema
        startDate: new Date(data.startDate),
        endDate: new Date(data.endDate)
      };
      
      console.log("Sending formatted data:", formattedData);
      const response = await apiRequest("PATCH", `/api/campaigns/${params?.id}`, formattedData);
      return response.json();
    },
    onSuccess: () => {
      setCurrentStep(2);
      toast({
        title: "Campaign updated",
        description: "Campaign details updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/campaigns/${params?.id}`] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update campaign: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update target audience mutation
  const updateTargetAudience = useMutation({
    mutationFn: async (data: TargetAudienceFormValues) => {
      // Format the data properly for the API
      const formattedData = {
        ...data,
        // Ensure arrays are handled correctly
        locations: Array.isArray(data.locations) ? data.locations : [],
        interests: Array.isArray(data.interests) ? data.interests : []
      };
      
      console.log("Sending target audience data:", formattedData);
      
      if (targetAudience?.id) {
        const response = await apiRequest("PATCH", `/api/campaigns/${params?.id}/target-audience`, formattedData);
        return response.json();
      } else {
        const response = await apiRequest("POST", `/api/campaigns/${params?.id}/target-audience`, formattedData);
        return response.json();
      }
    },
    onSuccess: () => {
      setCurrentStep(3);
      toast({
        title: "Target audience updated",
        description: "Target audience details updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/campaigns/${params?.id}/target-audience`] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update target audience: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update influencer criteria mutation
  const updateInfluencerCriteria = useMutation({
    mutationFn: async (data: InfluencerCriteriaFormValues) => {
      // Format the data properly for the API
      const formattedData = {
        ...data,
        // Ensure arrays and numbers are handled correctly
        categories: Array.isArray(data.categories) ? data.categories : [],
        minEngagementRate: typeof data.minEngagementRate === 'string' 
          ? parseFloat(data.minEngagementRate) 
          : data.minEngagementRate,
        // Convert comma-separated keywords to array if necessary
        keywords: data.keywords.split(',').map(k => k.trim()).filter(k => k !== '')
      };
      
      console.log("Sending influencer criteria data:", formattedData);
      
      if (influencerCriteria?.id) {
        const response = await apiRequest("PATCH", `/api/campaigns/${params?.id}/influencer-criteria`, formattedData);
        return response.json();
      } else {
        const response = await apiRequest("POST", `/api/campaigns/${params?.id}/influencer-criteria`, formattedData);
        return response.json();
      }
    },
    onSuccess: () => {
      toast({
        title: "Influencer criteria updated",
        description: "Influencer criteria updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/campaigns/${params?.id}/influencer-criteria`] });
      setLocation(`/campaigns/${params?.id}`);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update influencer criteria: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle campaign form submission
  const handleCampaignSubmit = (data: CampaignFormValues) => {
    setCampaignData(data);
    updateCampaign.mutate(data);
  };

  // Handle target audience form submission
  const handleAudienceSubmit = (data: TargetAudienceFormValues) => {
    setAudienceData(data);
    updateTargetAudience.mutate(data);
  };

  // Handle influencer criteria form submission
  const handleCriteriaSubmit = (data: InfluencerCriteriaFormValues) => {
    setCriteriaData(data);
    updateInfluencerCriteria.mutate(data);
  };

  // Loading state
  const isLoading = isCampaignLoading || isTargetAudienceLoading || isInfluencerCriteriaLoading;

  if (!match) {
    return <div>Campaign not found</div>;
  }

  return (
    <div>
      {/* TopBar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">
            {isLoading ? <Skeleton className="h-8 w-48" /> : `Edit Campaign: ${campaign?.name}`}
          </h1>
          <p className="text-slate-500 text-sm mt-1">Update your campaign details</p>
        </div>
        <div className="flex items-center gap-3">
          <Button 
            variant="outline" 
            onClick={() => setLocation(`/campaigns/${params?.id}`)}
          >
            Cancel
          </Button>
          <Button
            onClick={() => {
              if (currentStep === 1) {
                if (campaignData) {
                  updateCampaign.mutate(campaignData);
                } else {
                  document.getElementById('campaign-form-submit')?.click();
                }
              } else if (currentStep === 2) {
                if (audienceData) {
                  updateTargetAudience.mutate(audienceData);
                } else {
                  document.getElementById('target-audience-submit')?.click();
                }
              } else if (currentStep === 3) {
                if (criteriaData) {
                  updateInfluencerCriteria.mutate(criteriaData);
                } else {
                  document.getElementById('influencer-criteria-submit')?.click();
                }
              }
            }}
            disabled={isLoading}
          >
            {currentStep < 3 ? "Save & Continue" : "Save & Finish"}
          </Button>
        </div>
      </div>

      {/* Campaign Form */}
      {currentStep === 1 && (
        isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : (
          <CampaignForm 
            onSubmit={handleCampaignSubmit} 
            defaultValues={campaignData || undefined}
          />
        )
      )}

      {/* Target Audience */}
      {currentStep === 2 && (
        isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : (
          <TargetAudience 
            onSubmit={handleAudienceSubmit} 
            defaultValues={audienceData || undefined}
          />
        )
      )}

      {/* Influencer Criteria */}
      {currentStep === 3 && (
        isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : (
          <InfluencerCriteria 
            onSubmit={handleCriteriaSubmit} 
            defaultValues={criteriaData || undefined}
          />
        )
      )}
    </div>
  );
}