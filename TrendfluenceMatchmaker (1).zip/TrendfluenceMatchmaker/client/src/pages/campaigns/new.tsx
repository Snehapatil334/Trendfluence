import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import CampaignForm, { CampaignFormValues } from "@/components/campaign/campaign-form";
import TargetAudience, { TargetAudienceFormValues } from "@/components/campaign/target-audience";
import InfluencerCriteria, { InfluencerCriteriaFormValues } from "@/components/campaign/influencer-criteria";
import ResultsPreview from "@/components/campaign/results-preview";
import ScoreBreakdown from "@/components/campaign/score-breakdown";

export default function NewCampaign() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [campaignData, setCampaignData] = useState<CampaignFormValues | null>(null);
  const [audienceData, setAudienceData] = useState<TargetAudienceFormValues | null>(null);
  const [criteriaData, setCriteriaData] = useState<InfluencerCriteriaFormValues | null>(null);
  const [campaignId, setCampaignId] = useState<number | null>(null);

  // Create campaign mutation
  const createCampaign = useMutation({
    mutationFn: async (data: any) => {
      console.log("Submitting campaign data:", data);
      const response = await apiRequest("POST", "/api/campaigns", data);
      return response.json();
    },
    onSuccess: (data) => {
      setCampaignId(data.id);
      setCurrentStep(2);
      toast({
        title: "Campaign created",
        description: "Campaign details saved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create campaign: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Create target audience mutation
  const createTargetAudience = useMutation({
    mutationFn: async (data: TargetAudienceFormValues) => {
      const response = await apiRequest("POST", `/api/campaigns/${campaignId}/target-audience`, data);
      return response.json();
    },
    onSuccess: () => {
      setCurrentStep(3);
      toast({
        title: "Target audience saved",
        description: "Target audience details saved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to save target audience: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Create influencer criteria mutation
  const createInfluencerCriteria = useMutation({
    mutationFn: async (data: InfluencerCriteriaFormValues) => {
      const response = await apiRequest("POST", `/api/campaigns/${campaignId}/influencer-criteria`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Influencer criteria saved",
        description: "Influencer criteria saved successfully.",
      });
      // Start the matching process
      findMatches.mutate(campaignId as number);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to save influencer criteria: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Find matches mutation
  const findMatches = useMutation({
    mutationFn: async (campaignId: number) => {
      const response = await apiRequest("POST", `/api/campaigns/${campaignId}/match`, {});
      return response.json();
    },
    onSuccess: () => {
      setCurrentStep(4);
      queryClient.invalidateQueries({ queryKey: [`/api/campaigns/${campaignId}/matches`] });
      toast({
        title: "Influencers matched",
        description: "We've found influencers that match your campaign.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to match influencers: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle campaign form submission
  const handleCampaignSubmit = (data: any) => {
    // Store the original form data for future reference
    setCampaignData(data);
    
    // Submit the properly formatted data to the API
    createCampaign.mutate(data);
  };

  // Handle target audience form submission
  const handleAudienceSubmit = (data: TargetAudienceFormValues) => {
    setAudienceData(data);
    if (campaignId) {
      createTargetAudience.mutate(data);
    }
  };

  // Handle influencer criteria form submission
  const handleCriteriaSubmit = (data: InfluencerCriteriaFormValues) => {
    setCriteriaData(data);
    if (campaignId) {
      createInfluencerCriteria.mutate(data);
    }
  };

  // Handle launch campaign
  const handleLaunchCampaign = async () => {
    try {
      if (campaignId) {
        await apiRequest("PATCH", `/api/campaigns/${campaignId}`, { status: "active" });
        toast({
          title: "Campaign launched",
          description: "Your campaign is now active!",
        });
        setLocation("/campaigns");
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to launch campaign.",
        variant: "destructive",
      });
    }
  };

  // Handle save as draft
  const handleSaveAsDraft = async () => {
    try {
      if (campaignId) {
        await apiRequest("PATCH", `/api/campaigns/${campaignId}`, { status: "draft" });
        toast({
          title: "Campaign saved",
          description: "Your campaign has been saved as a draft.",
        });
        setLocation("/campaigns");
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save campaign as draft.",
        variant: "destructive",
      });
    }
  };

  return (
    <div>
      {/* TopBar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Campaign Builder</h1>
          <p className="text-slate-500 text-sm mt-1">Create a new campaign to find the perfect influencers</p>
        </div>
        <div className="flex items-center gap-3">
          <Button 
            variant="outline" 
            onClick={() => setLocation("/campaigns")}
          >
            Cancel
          </Button>
          <Button
            onClick={() => {
              if (currentStep === 1) {
                // If we have campaign data in state, use that directly (for prefilled forms)
                if (campaignData) {
                  createCampaign.mutate(campaignData);
                } else {
                  // Otherwise trigger form submission to validate and collect data
                  document.getElementById('campaign-form-submit')?.click();
                }
              } else if (currentStep === 2 && campaignId) {
                if (audienceData) {
                  createTargetAudience.mutate(audienceData);
                } else {
                  document.getElementById('target-audience-submit')?.click();
                }
              } else if (currentStep === 3 && campaignId) {
                if (criteriaData) {
                  createInfluencerCriteria.mutate(criteriaData);
                } else {
                  document.getElementById('influencer-criteria-submit')?.click();
                }
              }
            }}
          >
            {currentStep < 4 ? "Save & Continue" : "Review Campaign"}
          </Button>
        </div>
      </div>

      {/* Campaign Form */}
      {currentStep >= 1 && (
        <CampaignForm 
          onSubmit={handleCampaignSubmit} 
          defaultValues={campaignData || undefined}
        />
      )}

      {/* Target Audience */}
      {currentStep >= 2 && (
        <TargetAudience 
          onSubmit={handleAudienceSubmit} 
          defaultValues={audienceData || undefined}
        />
      )}

      {/* Influencer Criteria */}
      {currentStep >= 3 && (
        <InfluencerCriteria 
          onSubmit={handleCriteriaSubmit} 
          defaultValues={criteriaData || undefined}
        />
      )}

      {/* Results Preview */}
      {currentStep >= 4 && campaignId && (
        <>
          <ResultsPreview campaignId={campaignId} />
          <ScoreBreakdown campaignId={campaignId} />
        </>
      )}

      {/* Action Buttons */}
      {currentStep >= 4 && (
        <div className="flex justify-end gap-3 mb-8">
          <Button 
            variant="outline" 
            onClick={handleSaveAsDraft}
          >
            Save as Draft
          </Button>
          <Button 
            onClick={handleLaunchCampaign}
          >
            Launch Campaign
          </Button>
        </div>
      )}
    </div>
  );
}
