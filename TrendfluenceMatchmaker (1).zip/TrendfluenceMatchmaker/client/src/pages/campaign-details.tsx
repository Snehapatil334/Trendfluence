import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Campaign, InfluencerCriteria, TargetAudience } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { toast, useToast } from "@/hooks/use-toast";
import ScoreBreakdown from "@/components/campaign/score-breakdown";
import ResultsPreview from "@/components/campaign/results-preview";
import { CalendarDays, Clock, DollarSign, Target, Users, Youtube, Loader2, RefreshCw, Search } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";

export default function CampaignDetails() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute<{ id: string }>("/campaigns/:id");
  const [tabValue, setTabValue] = useState("overview");
  const [runMatchingMutation, setRunMatchingMutation] = useState(false);
  const [runYoutubeMatchingMutation, setRunYoutubeMatchingMutation] = useState(false);
  const [includeYoutubeSearch, setIncludeYoutubeSearch] = useState(false);
  const [youtubeMetadata, setYoutubeMetadata] = useState<{
    youtubeSearchQuery?: string;
    youtubeChannelsAdded?: number;
    totalInfluencersMatched?: number;
    searchTimestamp?: string;
  } | null>(null);
  const { toast } = useToast();
  
  // Fetch campaign data
  const { data: campaign, isLoading: isCampaignLoading } = useQuery<Campaign>({
    queryKey: [`/api/campaigns/${params?.id}`],
    enabled: !!params?.id,
  });
  
  // Fetch target audience
  const { data: targetAudience, isLoading: isTargetAudienceLoading } = useQuery<TargetAudience>({
    queryKey: [`/api/campaigns/${params?.id}/target-audience`],
    enabled: !!params?.id,
  });
  
  // Fetch influencer criteria
  const { data: influencerCriteria, isLoading: isInfluencerCriteriaLoading } = useQuery<InfluencerCriteria>({
    queryKey: [`/api/campaigns/${params?.id}/influencer-criteria`],
    enabled: !!params?.id,
  });
  
  // Debug logging
  useEffect(() => {
    console.log('Campaign data:', campaign);
    console.log('Target audience data:', targetAudience);
    console.log('Influencer criteria data:', influencerCriteria);
  }, [campaign, targetAudience, influencerCriteria]);
  
  // Mutation for running the matching algorithm
  const matchMutation = useMutation({
    mutationFn: async (campaignId: string) => {
      const response = await apiRequest('POST', `/api/campaigns/${campaignId}/match`);
      const data = await response.json();
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/campaigns/${params?.id}/matches`] });
      toast({
        title: "Success",
        description: "Influencer matching completed successfully",
      });
      setTabValue("matches");
    },
    onError: (error) => {
      console.error("Error matching influencers:", error);
      toast({
        title: "Error",
        description: "Failed to match influencers",
        variant: "destructive",
      });
    }
  });
  
  // Mutation for running the YouTube-enhanced matching algorithm
  const youtubeMatchMutation = useMutation({
    mutationFn: async (campaignId: string) => {
      const response = await apiRequest('POST', `/api/campaigns/${campaignId}/match-with-youtube`);
      const data = await response.json();
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [`/api/campaigns/${params?.id}/matches`] });
      
      // Extract metadata from response if available
      const meta = data?.meta;
      
      // Store metadata in state if available
      if (meta) {
        setYoutubeMetadata({
          youtubeSearchQuery: meta.youtubeSearchQuery,
          youtubeChannelsAdded: meta.youtubeChannelsAdded,
          totalInfluencersMatched: meta.totalInfluencersMatched,
          searchTimestamp: meta.searchTimestamp
        });
      }
      
      // Create success message with enhanced information if available
      let successMessage = "YouTube influencer matching completed successfully";
      if (meta) {
        successMessage += `. Found ${meta.youtubeChannelsAdded} new channels, with ${meta.totalInfluencersMatched} total matches.`;
      }
      
      toast({
        title: "Success",
        description: successMessage,
      });
      
      setTabValue("matches");
    },
    onError: (error) => {
      console.error("Error matching with YouTube:", error);
      toast({
        title: "Error",
        description: "Failed to match with YouTube influencers",
        variant: "destructive",
      });
    }
  });
  
  useEffect(() => {
    if (runMatchingMutation && params?.id) {
      matchMutation.mutate(params.id);
      setRunMatchingMutation(false);
    }
  }, [runMatchingMutation, params?.id, matchMutation]);
  
  useEffect(() => {
    if (runYoutubeMatchingMutation && params?.id) {
      youtubeMatchMutation.mutate(params.id);
      setRunYoutubeMatchingMutation(false);
    }
  }, [runYoutubeMatchingMutation, params?.id, youtubeMatchMutation]);
  
  // Helper function to format date
  const formatDate = (dateString: string | Date) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(date);
  };
  
  const isLoading = isCampaignLoading || isTargetAudienceLoading || isInfluencerCriteriaLoading;
  
  if (!match) {
    return <div>Campaign not found</div>;
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Button variant="link" className="p-0 text-slate-500 font-normal" onClick={() => setLocation("/campaigns")}>
              Campaigns
            </Button>
            <span className="text-slate-500">/</span>
            <span className="font-medium">{isCampaignLoading ? "Loading..." : campaign?.name}</span>
          </div>
          <h1 className="text-2xl font-bold">{isCampaignLoading ? <Skeleton className="h-8 w-48" /> : campaign?.name}</h1>
          <p className="text-slate-500 text-sm mt-1">
            {isCampaignLoading ? <Skeleton className="h-4 w-64" /> : `${campaign?.brand} • ${formatDate(campaign?.startDate || new Date())} - ${formatDate(campaign?.endDate || new Date())}`}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setLocation(`/campaigns/edit/${params?.id}`)}>
            Edit Campaign
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="default" disabled={matchMutation.isPending || youtubeMatchMutation.isPending}>
                {matchMutation.isPending ? "Matching..." : "Find Influencers"}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Run influencer matching</AlertDialogTitle>
                <AlertDialogDescription>
                  This will analyze the campaign requirements and find the best matching influencers from your database. This may take a moment to complete.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="p-4 border rounded-md mb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Youtube className="h-5 w-5 text-slate-500" />
                    <div>
                      <h4 className="font-medium">Include YouTube Search</h4>
                      <p className="text-sm text-slate-500">Find new influencers from YouTube that match campaign criteria</p>
                    </div>
                  </div>
                  <Switch
                    checked={includeYoutubeSearch}
                    onCheckedChange={setIncludeYoutubeSearch}
                    aria-label="Toggle YouTube search"
                  />
                </div>
              </div>
              
              <AlertDialogFooter className="flex justify-between items-center">
                <div></div>
                <div className="flex gap-2">
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={() => {
                      if (includeYoutubeSearch) {
                        setRunYoutubeMatchingMutation(true);
                      } else {
                        setRunMatchingMutation(true);
                      }
                    }}
                    disabled={matchMutation.isPending || youtubeMatchMutation.isPending}
                  >
                    {matchMutation.isPending || youtubeMatchMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <Search className="h-4 w-4 mr-2" />
                    )}
                    {includeYoutubeSearch ? "Run with YouTube Search" : "Run Matching"}
                  </AlertDialogAction>
                </div>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          {[1, 2, 3, 4].map(i => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500">Status</p>
                  <h4 className="text-2xl font-semibold mt-1">
                    <Badge className={
                      campaign?.status === "active" ? "bg-green-100 text-green-700" :
                      campaign?.status === "completed" ? "bg-blue-100 text-blue-700" :
                      "bg-slate-100 text-slate-700"
                    }>
                      {campaign?.status ? campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1) : "Draft"}
                    </Badge>
                  </h4>
                </div>
                <div className="bg-slate-100 p-3 rounded-full">
                  <Clock className="h-5 w-5 text-slate-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500">Budget</p>
                  <h4 className="text-2xl font-semibold mt-1">
                    ${campaign?.budget ? Number(campaign.budget).toLocaleString() : "0"}
                  </h4>
                </div>
                <div className="bg-slate-100 p-3 rounded-full">
                  <DollarSign className="h-5 w-5 text-slate-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500">Duration</p>
                  <h4 className="text-2xl font-semibold mt-1">
                    {campaign?.startDate && campaign?.endDate ? 
                      Math.ceil(
                        (new Date(campaign.endDate).getTime() - new Date(campaign.startDate).getTime()) / 
                        (1000 * 60 * 60 * 24)
                      ) : 0} days
                  </h4>
                </div>
                <div className="bg-slate-100 p-3 rounded-full">
                  <CalendarDays className="h-5 w-5 text-slate-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-500">Influencers Needed</p>
                  <h4 className="text-2xl font-semibold mt-1">
                    {campaign?.influencersNeeded}
                  </h4>
                </div>
                <div className="bg-slate-100 p-3 rounded-full">
                  <Users className="h-5 w-5 text-slate-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      <Tabs value={tabValue} onValueChange={setTabValue}>
        <TabsList className="mb-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="matches">Influencer Matches</TabsTrigger>
          <TabsTrigger value="scores">Score Breakdown</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Details</CardTitle>
                <CardDescription>Overview of campaign specifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {isLoading ? (
                  <>
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                  </>
                ) : (
                  <>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Description</h4>
                      <p className="mt-1">{campaign?.description || "No description provided"}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Campaign Type</h4>
                      <p className="mt-1">{campaign?.campaignType || "Not specified"}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Content Type</h4>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {Array.isArray(campaign?.contentTypes) && campaign.contentTypes.length > 0 ? 
                          campaign.contentTypes.map((contentType, index) => (
                            <Badge key={index} variant="outline">{contentType}</Badge>
                          )) : 
                          <span>Not specified</span>
                        }
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Target Audience</CardTitle>
                <CardDescription>Demographic and geographic targeting</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {isLoading ? (
                  <>
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                  </>
                ) : targetAudience ? (
                  <>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Age Range</h4>
                      <p className="mt-1">{targetAudience?.minAge || "18"} - {targetAudience?.maxAge || "65"} years</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Gender</h4>
                      <p className="mt-1">{targetAudience && targetAudience.gender ? 
                        targetAudience.gender.charAt(0).toUpperCase() + targetAudience.gender.slice(1) : 
                        "All"}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Locations</h4>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {Array.isArray(targetAudience?.locations) && targetAudience.locations.length > 0 ? 
                          targetAudience.locations.map((location, index) => (
                            <Badge key={index} variant="outline">{location}</Badge>
                          ))
                          : <Badge variant="outline">Global</Badge>
                        }
                      </div>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Interests</h4>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {Array.isArray(targetAudience?.interests) && targetAudience.interests.length > 0 ? 
                          targetAudience.interests.map((interest, index) => (
                            <Badge key={index} variant="outline">{interest}</Badge>
                          ))
                          : <Badge variant="outline">General</Badge>
                        }
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-slate-500">No target audience data available</p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Influencer Criteria</CardTitle>
                <CardDescription>Required influencer profile specifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {isLoading ? (
                  <>
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                  </>
                ) : influencerCriteria ? (
                  <>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Min. Subscribers</h4>
                      <p className="mt-1">{typeof influencerCriteria?.minSubscribers === 'number' ? 
                        influencerCriteria.minSubscribers.toLocaleString() : 
                        Number(influencerCriteria?.minSubscribers || 0).toLocaleString()}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Min. Engagement Rate</h4>
                      <p className="mt-1">
                        {influencerCriteria?.minEngagementRate ? 
                          (typeof influencerCriteria.minEngagementRate === 'number' ? 
                            influencerCriteria.minEngagementRate : 
                            Number(influencerCriteria.minEngagementRate)
                          ).toFixed(1) : "0.0"}%
                      </p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Keywords</h4>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {Array.isArray(influencerCriteria?.keywords) && influencerCriteria.keywords.length > 0 ? 
                          influencerCriteria.keywords.map((keyword, index) => (
                            <Badge key={index} variant="outline">{keyword}</Badge>
                          ))
                          : <Badge variant="outline">Any</Badge>
                        }
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-slate-500">No influencer criteria data available</p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Budget Allocation</CardTitle>
                <CardDescription>Financial planning for the campaign</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {isLoading ? (
                  <>
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                  </>
                ) : campaign ? (
                  <>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Total Budget</h4>
                      <p className="mt-1">${typeof campaign?.budget === 'number' ? 
                        campaign.budget.toLocaleString() : 
                        Number(campaign?.budget || 0).toLocaleString()}</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Per Influencer (avg.)</h4>
                      <p className="mt-1">
                        ${campaign?.influencersNeeded && Number(campaign.influencersNeeded) > 0 ? 
                          Math.round(Number(campaign.budget || 0) / Number(campaign.influencersNeeded)).toLocaleString() : 
                          Number(campaign.budget || 0).toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-slate-500">Status</h4>
                      <p className="mt-1 capitalize">{campaign?.status || "Draft"}</p>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-slate-500">No budget data available</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="matches">
          <div className="space-y-6">
            <Card className="bg-slate-50 border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 bg-slate-100 p-2 rounded-full">
                    <Youtube className="h-5 w-5 text-slate-600" />
                  </div>
                  <div className="flex-grow">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-sm font-medium text-slate-900">YouTube Integration</h3>
                        <p className="text-sm text-slate-500 mt-1">
                          {youtubeMetadata 
                            ? `Enhanced matching with YouTube search results.`
                            : `To find even more relevant influencers, use the "Include YouTube Search" option when matching.
                              This will search YouTube for channels related to your campaign and add them to your database.`
                          }
                        </p>
                      </div>
                      {youtubeMetadata && (
                        <Badge variant="outline" className="ml-2 bg-amber-50 text-amber-700 hover:bg-amber-50">
                          YouTube Data
                        </Badge>
                      )}
                    </div>
                    
                    {youtubeMetadata && (
                      <div className="mt-3 bg-white p-3 border border-slate-200 rounded-md text-xs">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <div>
                            <span className="text-slate-500">Search query:</span>
                            <span className="font-medium ml-1">"{youtubeMetadata.youtubeSearchQuery}"</span>
                          </div>
                          <div>
                            <span className="text-slate-500">Channels added:</span>
                            <span className="font-medium ml-1">{youtubeMetadata.youtubeChannelsAdded}</span>
                          </div>
                          <div>
                            <span className="text-slate-500">Total matches:</span>
                            <span className="font-medium ml-1">{youtubeMetadata.totalInfluencersMatched}</span>
                          </div>
                          <div>
                            <span className="text-slate-500">Last updated:</span>
                            <span className="font-medium ml-1">
                              {youtubeMetadata.searchTimestamp ? 
                                new Date(youtubeMetadata.searchTimestamp).toLocaleString() : 
                                "N/A"}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div className="mt-3">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="gap-1.5"
                        onClick={() => setRunYoutubeMatchingMutation(true)}
                        disabled={youtubeMatchMutation.isPending}
                      >
                        {youtubeMatchMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <RefreshCw className="h-4 w-4" />
                        )}
                        {youtubeMetadata ? "Refresh YouTube Matches" : "Find YouTube Matches"}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {params?.id && <ResultsPreview campaignId={parseInt(params.id)} />}
          </div>
        </TabsContent>
        
        <TabsContent value="scores">
          {params?.id && <ScoreBreakdown campaignId={parseInt(params.id)} />}
        </TabsContent>
      </Tabs>
    </div>
  );
}