import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Campaign, Influencer } from "@shared/schema";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import RecommendationAccuracy from "@/components/analytics/recommendation-accuracy";

export default function Analytics() {
  const { data: campaigns, isLoading: campaignsLoading } = useQuery<Campaign[]>({
    queryKey: ['/api/campaigns'],
  });

  const { data: influencers, isLoading: influencersLoading } = useQuery<Influencer[]>({
    queryKey: ['/api/influencers'],
  });

  // Get total budget across all campaigns
  const totalBudget = campaigns?.reduce((sum, campaign) => {
    return sum + (typeof campaign.budget === 'number' 
      ? campaign.budget 
      : parseFloat(String(campaign.budget)) || 0);
  }, 0) || 0;

  // Get average engagement rate across all influencers
  const averageEngagementRate = influencers?.length 
    ? influencers.reduce((sum, influencer) => {
        return sum + (typeof influencer.engagementRate === 'number' 
          ? influencer.engagementRate 
          : parseFloat(String(influencer.engagementRate)) || 0);
      }, 0) / influencers.length
    : 0;

  // Format numbers with K/M suffix
  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(0)}K`;
    }
    return num.toString();
  };

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(value);
  };

  // Calculate the total reach across all influencers
  const totalReach = influencers?.reduce((sum, influencer) => {
    return sum + influencer.subscribers;
  }, 0) || 0;

  // Prepare data for campaign performance chart
  const campaignPerformanceData = campaigns?.map(campaign => ({
    name: campaign.name,
    budget: typeof campaign.budget === 'number' ? campaign.budget : parseFloat(String(campaign.budget)) || 0,
    expectedROI: (typeof campaign.budget === 'number' ? campaign.budget : parseFloat(String(campaign.budget)) || 0) * 1.5 // Simple ROI calculation for demo
  }));

  // Prepare data for category distribution
  const categoryDistribution = [
    { name: 'Beauty', value: 15 },
    { name: 'Fitness', value: 25 },
    { name: 'Technology', value: 20 },
    { name: 'Fashion', value: 15 },
    { name: 'Gaming', value: 15 },
    { name: 'Others', value: 10 },
  ];

  // Monthly growth data
  const monthlyGrowthData = [
    { name: 'Jan', campaigns: 5, influencers: 15 },
    { name: 'Feb', campaigns: 7, influencers: 20 },
    { name: 'Mar', campaigns: 8, influencers: 28 },
    { name: 'Apr', campaigns: 10, influencers: 35 },
    { name: 'May', campaigns: 12, influencers: 45 },
    { name: 'Jun', campaigns: 15, influencers: 60 },
  ];

  // Chart colors
  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#64748B'];

  const isLoading = campaignsLoading || influencersLoading;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Analytics Dashboard</h1>
        <p className="text-slate-500">Track performance and analyze trends across campaigns and influencers.</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm font-medium text-slate-500">Total Campaigns</p>
                <h3 className="text-3xl font-bold mt-1">{campaigns?.length || 0}</h3>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm font-medium text-slate-500">Total Budget</p>
                <h3 className="text-3xl font-bold mt-1">{formatCurrency(totalBudget)}</h3>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm font-medium text-slate-500">Total Influencers</p>
                <h3 className="text-3xl font-bold mt-1">{influencers?.length || 0}</h3>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm font-medium text-slate-500">Total Reach</p>
                <h3 className="text-3xl font-bold mt-1">{formatNumber(totalReach)}</h3>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs defaultValue="campaign" className="mt-6">
        <TabsList className="mb-4">
          <TabsTrigger value="campaign">Campaign Analytics</TabsTrigger>
          <TabsTrigger value="influencer">Influencer Analytics</TabsTrigger>
          <TabsTrigger value="growth">Growth Trends</TabsTrigger>
          <TabsTrigger value="recommendation">Recommendation Accuracy</TabsTrigger>
        </TabsList>
        
        <TabsContent value="campaign">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Performance</CardTitle>
                <CardDescription>Budget allocation and expected ROI across campaigns</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <Skeleton className="h-80" />
                ) : (
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={campaignPerformanceData}
                        margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" angle={-45} textAnchor="end" height={70} />
                        <YAxis />
                        <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                        <Legend />
                        <Bar dataKey="budget" name="Budget" fill="#3B82F6" />
                        <Bar dataKey="expectedROI" name="Expected ROI" fill="#10B981" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Category Distribution</CardTitle>
                <CardDescription>Distribution of campaigns across categories</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <Skeleton className="h-80" />
                ) : (
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={categoryDistribution}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={90}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {categoryDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `${value}%`} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          <div className="flex justify-end mt-4">
            <Link href="/analytics/campaigns">
              <Button variant="outline" className="gap-2">
                View Detailed Campaign Analytics
                <ArrowRight size={16} />
              </Button>
            </Link>
          </div>
        </TabsContent>
        
        <TabsContent value="influencer">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Engagement Metrics</CardTitle>
                <CardDescription>Average engagement rate: {averageEngagementRate.toFixed(1)}%</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <Skeleton className="h-80" />
                ) : (
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={influencers?.slice(0, 5).map(inf => ({
                          name: inf.displayName,
                          rate: typeof inf.engagementRate === 'number' 
                            ? inf.engagementRate 
                            : parseFloat(String(inf.engagementRate)) || 0
                        }))}
                        margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" angle={-45} textAnchor="end" height={70} />
                        <YAxis />
                        <Tooltip formatter={(value) => `${value}%`} />
                        <Legend />
                        <Bar dataKey="rate" name="Engagement Rate (%)" fill="#F59E0B" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Audience Reach</CardTitle>
                <CardDescription>Total combined audience: {formatNumber(totalReach)}</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <Skeleton className="h-80" />
                ) : (
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={influencers?.slice(0, 5).map(inf => ({
                          name: inf.displayName,
                          subscribers: inf.subscribers,
                          avgViews: inf.avgViews
                        }))}
                        margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" angle={-45} textAnchor="end" height={70} />
                        <YAxis />
                        <Tooltip formatter={(value) => formatNumber(Number(value))} />
                        <Legend />
                        <Bar dataKey="subscribers" name="Subscribers" fill="#8B5CF6" />
                        <Bar dataKey="avgViews" name="Avg. Views" fill="#EC4899" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          <div className="flex justify-end mt-4">
            <Link href="/analytics/audience">
              <Button variant="outline" className="gap-2">
                View Detailed Audience Insights
                <ArrowRight size={16} />
              </Button>
            </Link>
          </div>
        </TabsContent>
        
        <TabsContent value="growth">
          <Card>
            <CardHeader>
              <CardTitle>Platform Growth Trends</CardTitle>
              <CardDescription>Monthly growth in campaigns and influencers</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-80" />
              ) : (
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={monthlyGrowthData}
                      margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="campaigns" 
                        name="Campaigns" 
                        stroke="#3B82F6" 
                        activeDot={{ r: 8 }} 
                        strokeWidth={2}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="influencers" 
                        name="Influencers" 
                        stroke="#10B981" 
                        strokeWidth={2}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="recommendation">
          <RecommendationAccuracy />
        </TabsContent>
      </Tabs>
    </div>
  );
}