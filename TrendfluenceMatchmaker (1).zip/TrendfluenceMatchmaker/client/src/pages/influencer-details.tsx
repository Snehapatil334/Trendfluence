import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Influencer } from "@shared/schema";
import { 
  ArrowLeft, 
  Instagram, 
  Twitter, 
  Youtube,
  User,
  CalendarDays,
  BarChart3,
  Users,
  DollarSign,
  MapPin,
  Percent,
  Globe
} from "lucide-react";
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend 
} from "recharts";

export default function InfluencerDetails() {
  const { id } = useParams();
  const influencerId = parseInt(id);

  const { data: influencer, isLoading } = useQuery<Influencer>({
    queryKey: [`/api/influencers/${influencerId}`],
    enabled: !isNaN(influencerId),
  });

  const { data: categories } = useQuery<any[]>({
    queryKey: ['/api/categories'],
  });

  // Format numbers with K/M suffix
  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(0)}K`;
    }
    return num.toString();
  };

  // Get category names based on IDs
  const getCategoryNames = (categoryIds: number[]) => {
    if (!categories) return [];
    return categoryIds.map(id => {
      const category = categories.find(c => c.id === id);
      return category ? category.name : '';
    }).filter(Boolean);
  };

  // Mock engagement data for demonstration
  const generateEngagementData = () => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentMonth = new Date().getMonth();
    
    return months.slice(0, 6).map((month, index) => {
      const baseEngagement = influencer ? parseFloat(String(influencer.engagementRate)) : 4;
      // Add some variation to the engagement rates
      const randomVariation = Math.random() * 1.5 - 0.75; // Between -0.75 and 0.75
      return {
        name: months[(currentMonth - 5 + index) % 12],
        rate: Math.max(0.5, baseEngagement + randomVariation).toFixed(1),
      };
    });
  };

  // Mock demographic data for visualization
  const demographicData = [
    { name: 'Male', value: 65 },
    { name: 'Female', value: 35 },
  ];

  const ageData = [
    { name: '13-17', value: 5 },
    { name: '18-24', value: 30 },
    { name: '25-34', value: 40 },
    { name: '35-44', value: 15 },
    { name: '45+', value: 10 },
  ];

  // Chart colors
  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

  return (
    <div>
      <div className="mb-6">
        <Link href="/influencers">
          <Button variant="ghost" className="pl-0 gap-1">
            <ArrowLeft className="h-4 w-4" />
            Back to Influencers
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="space-y-6">
          <Card>
            <CardContent className="p-0">
              <Skeleton className="w-full h-40" />
              <div className="p-6 flex flex-col md:flex-row items-start md:items-end gap-4 relative">
                <Skeleton className="w-24 h-24 rounded-full absolute -top-12 left-6 border-4 border-white" />
                <div className="md:ml-28 mt-16 md:mt-0 w-full">
                  <div className="flex flex-col md:flex-row justify-between gap-4">
                    <div>
                      <Skeleton className="h-8 w-48 mb-2" />
                      <Skeleton className="h-4 w-32 mb-4" />
                      <div className="flex flex-wrap gap-2">
                        <Skeleton className="h-6 w-20 rounded-full" />
                        <Skeleton className="h-6 w-24 rounded-full" />
                        <Skeleton className="h-6 w-16 rounded-full" />
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Skeleton className="h-10 w-32" />
                      <Skeleton className="h-10 w-32" />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map(i => (
              <Skeleton key={i} className="h-24" />
            ))}
          </div>

          <Card>
            <CardContent className="p-6">
              <Skeleton className="h-6 w-32 mb-4" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-3/4" />
            </CardContent>
          </Card>
        </div>
      ) : influencer ? (
        <div className="space-y-6">
          {/* Profile header */}
          <Card>
            <CardContent className="p-0">
              <div 
                className="h-40 bg-cover bg-center bg-slate-100" 
                style={influencer.bannerImageUrl ? { backgroundImage: `url(${influencer.bannerImageUrl})` } : {}}
              ></div>
              <div className="p-6 flex flex-col md:flex-row items-start md:items-end gap-4 relative">
                <img 
                  src={influencer.profileImageUrl || "https://via.placeholder.com/96"} 
                  alt={influencer.displayName} 
                  className="w-24 h-24 rounded-full absolute -top-12 left-6 border-4 border-white object-cover"
                />
                <div className="md:ml-28 mt-16 md:mt-0 w-full">
                  <div className="flex flex-col md:flex-row justify-between gap-4">
                    <div>
                      <h1 className="text-2xl font-bold">{influencer.channelTitle}</h1>
                      <p className="text-slate-500 mb-4">{influencer.displayName}</p>
                      <div className="flex flex-wrap gap-2">
                        {getCategoryNames(influencer.categories as number[]).map((category, index) => (
                          <Badge key={index} variant="secondary" className="bg-slate-100 text-slate-700">
                            {category}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button variant="outline" className="gap-2">
                        <Youtube className="h-4 w-4" />
                        Channel
                      </Button>
                      <Button className="gap-2">
                        <Users className="h-4 w-4" />
                        Add to Campaign
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Stats cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="bg-primary-100 p-3 rounded-full">
                  <Users className="h-5 w-5 text-primary-500" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Subscribers</p>
                  <h3 className="text-xl font-bold">{formatNumber(influencer.subscribers)}</h3>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="bg-green-100 p-3 rounded-full">
                  <BarChart3 className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Avg. Views</p>
                  <h3 className="text-xl font-bold">{formatNumber(influencer.avgViews)}</h3>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="bg-accent-100 p-3 rounded-full">
                  <Percent className="h-5 w-5 text-accent-500" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Engagement Rate</p>
                  <h3 className="text-xl font-bold">
                    {typeof influencer.engagementRate === 'number'
                      ? `${influencer.engagementRate.toFixed(1)}%`
                      : `${parseFloat(String(influencer.engagementRate)).toFixed(1)}%`}
                  </h3>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex items-center gap-4">
                <div className="bg-red-100 p-3 rounded-full">
                  <DollarSign className="h-5 w-5 text-red-500" />
                </div>
                <div>
                  <p className="text-sm text-slate-500">Est. Cost</p>
                  <h3 className="text-xl font-bold">
                    {influencer.estimatedCost 
                      ? `$${typeof influencer.estimatedCost === 'number' 
                          ? influencer.estimatedCost.toFixed(0) 
                          : Number(influencer.estimatedCost).toFixed(0)}`
                      : 'N/A'}
                  </h3>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Description */}
          {influencer.description && (
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">About</h3>
                <p className="text-slate-700 whitespace-pre-line">{influencer.description}</p>
              </CardContent>
            </Card>
          )}

          {/* Tabs for analytics */}
          <Tabs defaultValue="demographics">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="demographics">Demographics</TabsTrigger>
              <TabsTrigger value="engagement">Engagement</TabsTrigger>
              <TabsTrigger value="tags">Content Tags</TabsTrigger>
            </TabsList>
            <TabsContent value="demographics">
              <Card>
                <CardHeader>
                  <CardTitle>Audience Demographics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                      <h4 className="text-sm font-semibold text-center mb-4">Gender Distribution</h4>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={demographicData}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            >
                              {demographicData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-semibold text-center mb-4">Age Distribution</h4>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={ageData}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            >
                              {ageData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 flex items-center justify-center">
                    <div className="flex items-center gap-1 text-sm text-slate-500">
                      <MapPin className="h-4 w-4" />
                      <span>Primary Location: {influencer.location || "Unknown"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="engagement">
              <Card>
                <CardHeader>
                  <CardTitle>Engagement Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={generateEngagementData()}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip 
                          formatter={(value) => [`${value}%`, 'Engagement Rate']}
                        />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="rate" 
                          name="Engagement Rate" 
                          stroke="#3B82F6" 
                          activeDot={{ r: 8 }} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="mt-6 grid grid-cols-3 gap-4 text-center">
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <p className="text-xs text-slate-500 mb-1">Avg. Comments</p>
                      <p className="font-medium">
                        {formatNumber(Math.floor(influencer.avgViews * (parseFloat(String(influencer.engagementRate)) / 100) * 0.15))}
                      </p>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <p className="text-xs text-slate-500 mb-1">Avg. Likes</p>
                      <p className="font-medium">
                        {formatNumber(Math.floor(influencer.avgViews * (parseFloat(String(influencer.engagementRate)) / 100) * 0.85))}
                      </p>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <p className="text-xs text-slate-500 mb-1">Avg. View Duration</p>
                      <p className="font-medium">
                        {Math.floor(5 + Math.random() * 4)}:{Math.floor(10 + Math.random() * 50).toString().padStart(2, '0')}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="tags">
              <Card>
                <CardHeader>
                  <CardTitle>Content Tags & Keywords</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {(influencer.tags as string[]).map((tag, index) => (
                      <Badge key={index} className="bg-primary-50 text-primary-700 hover:bg-primary-100 px-3 py-1.5 text-sm">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <div className="mt-8">
                    <h4 className="text-sm font-semibold mb-3">Recent Content Themes</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 border border-slate-200 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="h-3 w-3 rounded-full bg-primary-500"></div>
                          <h5 className="font-medium">{(influencer.tags as string[])[0] || "General Content"}</h5>
                        </div>
                        <p className="text-sm text-slate-500">45% of recent content</p>
                      </div>
                      
                      <div className="p-4 border border-slate-200 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="h-3 w-3 rounded-full bg-green-500"></div>
                          <h5 className="font-medium">{(influencer.tags as string[])[1] || "Reviews"}</h5>
                        </div>
                        <p className="text-sm text-slate-500">30% of recent content</p>
                      </div>
                      
                      <div className="p-4 border border-slate-200 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="h-3 w-3 rounded-full bg-accent-500"></div>
                          <h5 className="font-medium">{(influencer.tags as string[])[2] || "Tutorials"}</h5>
                        </div>
                        <p className="text-sm text-slate-500">25% of recent content</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      ) : (
        <Card>
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-semibold mb-2">Influencer Not Found</h2>
            <p className="text-slate-500 mb-4">The influencer you're looking for doesn't exist or has been removed.</p>
            <Link href="/influencers">
              <Button>Return to Influencers</Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
