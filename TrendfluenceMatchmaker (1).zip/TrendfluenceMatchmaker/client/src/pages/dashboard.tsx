import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Megaphone, Users, TrendingUp, PlusCircle } from "lucide-react";

export default function Dashboard() {
  // Fetch campaigns and influencers data
  const { data: campaigns, isLoading: isLoadingCampaigns } = useQuery({
    queryKey: ['/api/campaigns'],
  });

  const { data: influencers, isLoading: isLoadingInfluencers } = useQuery({
    queryKey: ['/api/influencers'],
  });

  // Calculate totals
  const totalCampaigns = campaigns?.length || 0;
  const totalInfluencers = influencers?.length || 0;
  const totalAudience = influencers?.reduce((sum, inf) => sum + inf.subscribers, 0) || 0;

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-slate-500 text-sm mt-1">Welcome to your campaign management dashboard</p>
        </div>
        <Link href="/campaigns/new">
          <Button className="gap-2">
            <PlusCircle className="h-4 w-4" />
            New Campaign
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="bg-primary-100 p-3 rounded-full">
                <Megaphone className="h-6 w-6 text-primary-500" />
              </div>
              <div>
                <p className="text-sm text-slate-500">Total Campaigns</p>
                <h3 className="text-2xl font-bold">{totalCampaigns}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="bg-secondary-100 p-3 rounded-full">
                <Users className="h-6 w-6 text-secondary-500" />
              </div>
              <div>
                <p className="text-sm text-slate-500">Influencer Network</p>
                <h3 className="text-2xl font-bold">{totalInfluencers}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="bg-accent-100 p-3 rounded-full">
                <TrendingUp className="h-6 w-6 text-accent-500" />
              </div>
              <div>
                <p className="text-sm text-slate-500">Total Audience Reach</p>
                <h3 className="text-2xl font-bold">
                  {totalAudience > 1000000 
                    ? `${(totalAudience / 1000000).toFixed(1)}M` 
                    : `${(totalAudience / 1000).toFixed(0)}K`}
                </h3>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Campaigns</CardTitle>
            <CardDescription>Your latest active campaigns</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {isLoadingCampaigns ? (
                <p className="text-sm text-slate-500">Loading campaigns...</p>
              ) : campaigns && campaigns.length > 0 ? (
                campaigns.slice(0, 5).map((campaign) => (
                  <div key={campaign.id} className="flex items-start gap-3">
                    <div className="bg-slate-100 p-2 rounded-md">
                      <Megaphone className="h-4 w-4 text-slate-500" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium">{campaign.name}</h4>
                      <p className="text-xs text-slate-500">{campaign.brand}</p>
                      <div className="text-xs text-primary-500 mt-1">
                        <Link href={`/campaigns/${campaign.id}`}>View details</Link>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4">
                  <p className="text-sm text-slate-500 mb-3">No campaigns yet</p>
                  <Link href="/campaigns/new">
                    <Button size="sm">Create your first campaign</Button>
                  </Link>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Influencers</CardTitle>
            <CardDescription>Highest performing influencers in your network</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {isLoadingInfluencers ? (
                <p className="text-sm text-slate-500">Loading influencers...</p>
              ) : influencers && influencers.length > 0 ? (
                influencers
                  .sort((a, b) => b.engagementRate - a.engagementRate)
                  .slice(0, 5)
                  .map((influencer) => (
                    <div key={influencer.id} className="flex items-center gap-3">
                      <img 
                        src={influencer.profileImageUrl} 
                        alt={influencer.displayName} 
                        className="w-10 h-10 rounded-full object-cover" 
                      />
                      <div>
                        <h4 className="text-sm font-medium">{influencer.channelTitle}</h4>
                        <div className="flex items-center text-xs text-slate-500">
                          <span>{(influencer.subscribers / 1000).toFixed(0)}K subscribers</span>
                          <span className="mx-1">•</span>
                          <span>{influencer.engagementRate}% engagement</span>
                        </div>
                      </div>
                    </div>
                  ))
              ) : (
                <p className="text-sm text-slate-500 text-center py-4">No influencers available</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Campaign Insights</CardTitle>
            <CardDescription>Performance metrics and suggestions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 bg-primary-50 rounded-lg border border-primary-100">
                <div className="flex gap-3">
                  <div className="bg-primary-100 p-1.5 rounded-full h-fit">
                    <TrendingUp className="h-4 w-4 text-primary-500" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-primary-700">Audience growth opportunity</h4>
                    <p className="text-xs text-slate-600 mt-1">Health & Fitness category influencers are showing 22% higher engagement rates this month</p>
                  </div>
                </div>
              </div>
              
              <div className="p-3 bg-secondary-50 rounded-lg border border-secondary-100">
                <div className="flex gap-3">
                  <div className="bg-secondary-100 p-1.5 rounded-full h-fit">
                    <TrendingUp className="h-4 w-4 text-secondary-500" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-secondary-700">Content opportunity</h4>
                    <p className="text-xs text-slate-600 mt-1">Short-form video content is generating 3.5x more engagement than standard videos</p>
                  </div>
                </div>
              </div>
              
              <div className="p-3 bg-accent-50 rounded-lg border border-accent-100">
                <div className="flex gap-3">
                  <div className="bg-accent-100 p-1.5 rounded-full h-fit">
                    <TrendingUp className="h-4 w-4 text-accent-500" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-accent-700">Budget optimization</h4>
                    <p className="text-xs text-slate-600 mt-1">Micro-influencers (10K-50K followers) are delivering 40% better ROI than larger accounts</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
