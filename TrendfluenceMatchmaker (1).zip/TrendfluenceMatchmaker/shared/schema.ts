import { pgTable, text, serial, integer, boolean, decimal, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table with enhanced fields
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  companyName: text("company_name").notNull(),
  role: text("role").default("user"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users, {
  username: (schema) => schema.min(3, "Username must be at least 3 characters"),
  password: (schema) => schema.min(6, "Password must be at least 6 characters"),
  email: (schema) => schema.email("Please enter a valid email address"),
  companyName: (schema) => schema.min(2, "Company name must be at least 2 characters"),
}).pick({
  username: true,
  password: true,
  email: true,
  companyName: true,
});

export const loginUserSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type User = typeof users.$inferSelect;

// Categories for influencers and campaigns
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
});

export const insertCategorySchema = createInsertSchema(categories);
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

// Campaign details
export const campaigns = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  brand: text("brand").notNull(),
  campaignType: text("campaign_type").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  budget: decimal("budget", { precision: 10, scale: 2 }).notNull(),
  influencersNeeded: integer("influencers_needed").notNull(),
  description: text("description").notNull(),
  contentTypes: jsonb("content_types").notNull(), // Array of content types
  status: text("status").notNull().default("draft"), // draft, active, completed
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Target audience for campaigns
export const campaignTargetAudience = pgTable("campaign_target_audience", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").references(() => campaigns.id).notNull(),
  minAge: integer("min_age").notNull(),
  maxAge: integer("max_age").notNull(),
  gender: text("gender").notNull(), // all, male, female
  locations: jsonb("locations").notNull(), // Array of location strings
  interests: jsonb("interests").notNull(), // Array of interest strings
});

// Influencer criteria for campaigns
export const campaignInfluencerCriteria = pgTable("campaign_influencer_criteria", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").references(() => campaigns.id).notNull(),
  categories: jsonb("categories").notNull(), // Array of category ids
  minSubscribers: integer("min_subscribers").notNull(),
  minEngagementRate: decimal("min_engagement_rate", { precision: 5, scale: 2 }).notNull(),
  keywords: jsonb("keywords").notNull(), // Array of keyword strings
});

// YouTube influencers
export const influencers = pgTable("influencers", {
  id: serial("id").primaryKey(),
  channelId: text("channel_id").notNull().unique(),
  channelTitle: text("channel_title").notNull(),
  displayName: text("display_name").notNull(),
  profileImageUrl: text("profile_image_url"),
  bannerImageUrl: text("banner_image_url"),
  description: text("description"),
  subscribers: integer("subscribers").notNull(),
  totalViews: integer("total_views").notNull(),
  avgViews: integer("avg_views").notNull(),
  engagementRate: decimal("engagement_rate", { precision: 5, scale: 2 }).notNull(),
  estimatedCost: decimal("estimated_cost", { precision: 10, scale: 2 }),
  location: text("location"),
  categories: jsonb("categories").notNull(), // Array of category ids
  tags: jsonb("tags").notNull(), // Array of tag strings
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

// Campaign-Influencer matches
export const influencerMatches = pgTable("influencer_matches", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").references(() => campaigns.id).notNull(),
  influencerId: integer("influencer_id").references(() => influencers.id).notNull(),
  performanceScore: decimal("performance_score", { precision: 5, scale: 2 }).notNull(),
  audienceScore: decimal("audience_score", { precision: 5, scale: 2 }).notNull(),
  contentScore: decimal("content_score", { precision: 5, scale: 2 }).notNull(),
  budgetScore: decimal("budget_score", { precision: 5, scale: 2 }).notNull(),
  overallScore: decimal("overall_score", { precision: 5, scale: 2 }).notNull(),
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Define relations
export const campaignsRelations = relations(campaigns, ({ many }) => ({
  targetAudience: many(campaignTargetAudience),
  influencerCriteria: many(campaignInfluencerCriteria),
  matches: many(influencerMatches),
}));

export const influencersRelations = relations(influencers, ({ many }) => ({
  matches: many(influencerMatches),
}));

export const influencerMatchesRelations = relations(influencerMatches, ({ one }) => ({
  campaign: one(campaigns, { fields: [influencerMatches.campaignId], references: [campaigns.id] }),
  influencer: one(influencers, { fields: [influencerMatches.influencerId], references: [influencers.id] }),
}));

export const campaignTargetAudienceRelations = relations(campaignTargetAudience, ({ one }) => ({
  campaign: one(campaigns, { fields: [campaignTargetAudience.campaignId], references: [campaigns.id] }),
}));

export const campaignInfluencerCriteriaRelations = relations(campaignInfluencerCriteria, ({ one }) => ({
  campaign: one(campaigns, { fields: [campaignInfluencerCriteria.campaignId], references: [campaigns.id] }),
}));

// Validation schemas
export const insertCampaignSchema = createInsertSchema(campaigns)
  .extend({
    // Override the date fields to accept string inputs and convert them to Date objects
    startDate: z.preprocess(
      (val) => val instanceof Date ? val : new Date(val as string),
      z.date()
    ),
    endDate: z.preprocess(
      (val) => val instanceof Date ? val : new Date(val as string),
      z.date()
    ),
    // Override the budget field to ensure it's a string
    budget: z.preprocess(
      (val) => String(val),
      z.string()
    ),
  })
  .refine(
    (data) => {
      // Custom validation for the name and brand fields
      return data.name.length >= 3 && data.brand.length >= 2;
    },
    {
      message: "Campaign name must be at least 3 characters and brand must be at least 2 characters",
      path: ["name", "brand"],
    }
  )
  .refine(
    (data) => {
      // Custom validation for budget and influencersNeeded
      return Number(data.budget) > 0 && Number(data.influencersNeeded) > 0;
    },
    {
      message: "Budget and number of influencers must be positive",
      path: ["budget", "influencersNeeded"],
    }
  );

export const insertTargetAudienceSchema = createInsertSchema(campaignTargetAudience, {
  minAge: (schema) => schema.refine((val) => Number(val) >= 13, "Minimum age must be at least 13"),
  maxAge: (schema) => schema.refine((val) => Number(val) >= 13, "Maximum age must be at least 13"),
});

export const insertInfluencerCriteriaSchema = createInsertSchema(campaignInfluencerCriteria)
  .extend({
    // Override the minEngagementRate field to accept number inputs and convert them to string
    minEngagementRate: z.preprocess(
      (val) => String(val),
      z.string()
    ),
  });

export const insertInfluencerSchema = createInsertSchema(influencers, {
  channelTitle: (schema) => schema.min(3, "Channel title must be at least 3 characters"),
  displayName: (schema) => schema.min(2, "Display name must be at least 2 characters"),
  subscribers: (schema) => schema.refine((val) => Number(val) >= 0, "Subscribers cannot be negative"),
});

export const insertInfluencerMatchSchema = createInsertSchema(influencerMatches);

// Export types
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Campaign = typeof campaigns.$inferSelect;

export type InsertTargetAudience = z.infer<typeof insertTargetAudienceSchema>;
export type TargetAudience = typeof campaignTargetAudience.$inferSelect;

export type InsertInfluencerCriteria = z.infer<typeof insertInfluencerCriteriaSchema>;
export type InfluencerCriteria = typeof campaignInfluencerCriteria.$inferSelect;

export type InsertInfluencer = z.infer<typeof insertInfluencerSchema>;
export type Influencer = typeof influencers.$inferSelect;

export type InsertInfluencerMatch = z.infer<typeof insertInfluencerMatchSchema>;
export type InfluencerMatch = typeof influencerMatches.$inferSelect;
