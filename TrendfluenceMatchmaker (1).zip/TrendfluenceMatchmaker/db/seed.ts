import { db } from "./index";
import * as schema from "@shared/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "../server/storage";

async function seed() {
  try {
    // Create test user if it doesn't exist
    const existingUser = await db.query.users.findFirst({
      where: eq(schema.users.email, "test@example.com"),
    });
    
    if (!existingUser) {
      console.log("Seeding test user...");
      await db.insert(schema.users).values({
        username: "testuser",
        email: "test@example.com",
        password: await hashPassword("password123"),
        companyName: "Test Company",
        role: "admin",
        createdAt: new Date(),
        updatedAt: new Date()
      });
      console.log("Test user created successfully!");
    }
    
    // Categories
    const existingCategories = await db.select().from(schema.categories);
    
    if (existingCategories.length === 0) {
      console.log("Seeding categories...");
      await db.insert(schema.categories).values([
        { name: "Health & Fitness", description: "Health, fitness, and workout related content" },
        { name: "Vegan/Vegetarian", description: "Plant-based diet and lifestyle content" },
        { name: "Food & Cooking", description: "Food recipes, cooking techniques, and culinary content" },
        { name: "Lifestyle", description: "General lifestyle content covering various aspects of daily life" },
        { name: "Wellness", description: "Mental, physical and emotional wellness content" },
        { name: "Sustainability", description: "Eco-friendly, sustainable living content" },
        { name: "Beauty", description: "Beauty, skincare, and makeup content" },
        { name: "Tech", description: "Technology, gadgets, and digital content" },
        { name: "Travel", description: "Travel, tourism, and adventure content" },
        { name: "Fashion", description: "Fashion, clothing, and style content" },
        { name: "Gaming", description: "Video games and gaming culture content" },
        { name: "Education", description: "Educational and informative content" },
        { name: "Business", description: "Business, entrepreneurship, and career content" },
        { name: "Entertainment", description: "Entertainment, fun, and creative content" },
      ]);
    }

    // Check if we have influencers
    const existingInfluencers = await db.select().from(schema.influencers);
    
    if (existingInfluencers.length === 0) {
      console.log("Seeding mock influencers for demonstration...");
      
      // Get category IDs
      const categoryList = await db.select().from(schema.categories);
      const categoryMap = new Map(categoryList.map(cat => [cat.name, cat.id]));
      
      // Sample influencers based on design reference
      await db.insert(schema.influencers).values([
        {
          channelId: "UC123456789",
          channelTitle: "FitWithEmily",
          displayName: "Emily Chen",
          profileImageUrl: "https://images.unsplash.com/photo-1602736294692-8e3c0aa7b8c0",
          bannerImageUrl: "https://images.unsplash.com/photo-1574269909862-7e1d70bb8078",
          description: "Health and fitness channel focusing on plant-based nutrition and workouts",
          subscribers: 245000,
          totalViews: 12000000,
          avgViews: 83000,
          engagementRate: 4.7,
          estimatedCost: 1800,
          location: "United States",
          categories: [categoryMap.get("Health & Fitness"), categoryMap.get("Vegan/Vegetarian")],
          tags: ["plant-based", "workout", "fitness"],
          lastUpdated: new Date(),
        },
        {
          channelId: "UC987654321",
          channelTitle: "Green Living Guide",
          displayName: "Marcus Johnson",
          profileImageUrl: "https://images.unsplash.com/photo-1628157588553-5eeea00af15c",
          bannerImageUrl: "https://images.unsplash.com/photo-1596025830727-9a2bb09239e1",
          description: "Sustainable living and eco-friendly lifestyle tips with a focus on vegan nutrition",
          subscribers: 132000,
          totalViews: 7500000,
          avgViews: 48000,
          engagementRate: 5.2,
          estimatedCost: 1450,
          location: "Canada",
          categories: [categoryMap.get("Vegan/Vegetarian"), categoryMap.get("Sustainability")],
          tags: ["vegan", "sustainability", "eco-friendly"],
          lastUpdated: new Date(),
        },
        {
          channelId: "UC567890123",
          channelTitle: "NutritionByNature",
          displayName: "Alex Rivera",
          profileImageUrl: "https://images.unsplash.com/photo-1583864697784-a0efc8379f70",
          bannerImageUrl: "https://images.unsplash.com/photo-1600443299762-7a743123645d",
          description: "Nutrition advice, supplement reviews, and fitness routines for optimal health",
          subscribers: 325000,
          totalViews: 18000000,
          avgViews: 112000,
          engagementRate: 3.8,
          estimatedCost: 2600,
          location: "United States",
          categories: [categoryMap.get("Health & Fitness"), categoryMap.get("Wellness")],
          tags: ["nutrition", "supplements", "fitness"],
          lastUpdated: new Date(),
        },
        {
          channelId: "UC543216789",
          channelTitle: "Organic Kitchen",
          displayName: "Sarah Miller",
          profileImageUrl: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce",
          bannerImageUrl: "https://images.unsplash.com/photo-1556911220-bda9d241c8b3",
          description: "Organic cooking, meal prep, and healthy eating for the whole family",
          subscribers: 185000,
          totalViews: 9800000,
          avgViews: 67000,
          engagementRate: 4.2,
          estimatedCost: 1650,
          location: "United Kingdom",
          categories: [categoryMap.get("Food & Cooking"), categoryMap.get("Vegan/Vegetarian")],
          tags: ["organic", "healthy cooking", "meal prep"],
          lastUpdated: new Date(),
        },
        {
          channelId: "UC987651234",
          channelTitle: "ActiveLifestyle",
          displayName: "James Wilson",
          profileImageUrl: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61",
          bannerImageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b",
          description: "Active lifestyle, outdoor workouts, and adventure sports",
          subscribers: 275000,
          totalViews: 14500000,
          avgViews: 92000,
          engagementRate: 4.5,
          estimatedCost: 2200,
          location: "Australia",
          categories: [categoryMap.get("Health & Fitness"), categoryMap.get("Lifestyle")],
          tags: ["active lifestyle", "outdoor fitness", "adventure"],
          lastUpdated: new Date(),
        },
      ]);
    }

    console.log("Seed completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
